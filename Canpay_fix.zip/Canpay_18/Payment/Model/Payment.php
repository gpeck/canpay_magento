<?php

namespace CanPay\Payment\Model;

use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Payment\Helper\Data;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Payment\Model\Method\Logger;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Directory\Helper\Data as DirectoryHelper;
use Psr\Log\LoggerInterface;
use CanPay\Payment\Helper\Data as Helper;
use CanPay\Payment\Helper\Api as HelperApi;
use Magento\Framework\Message\ManagerInterface;

class Payment extends \Magento\Payment\Model\Method\AbstractMethod {

    const CODE = 'canpaypayment';

    protected $_code = self::CODE;

    /**
     *
     * @var bool
     */
    protected $_canAuthorize = true;

    /**
     *
     * @var bool
     */
    protected $_canVoid = true;

    /**
     *
     * @var Logger
     */
    protected $paymentLogger;

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var HelperApi
     */
    protected $helperApi;

    /**
     *
     * @var ManagerInterface
     */
    protected $messageManager;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param ExtensionAttributesFactory $extensionFactory
     * @param AttributeValueFactory $customAttributeFactory
     * @param Data $paymentData
     * @param ScopeConfigInterface $scopeConfig
     * @param Logger $paymentLogger
     * @param LoggerInterface $logger
     * @param Helper $helper
     * @param HelperApi $helperApi
     * @param ManagerInterface $messageManager
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param array $data
     * @param DirectoryHelper|null $directory
     */
    public function __construct (
        Context $context,
        Registry $registry,
        ExtensionAttributesFactory $extensionFactory,
        AttributeValueFactory $customAttributeFactory,
        Data $paymentData,
        ScopeConfigInterface $scopeConfig,
        Logger $paymentLogger,
        LoggerInterface $logger,
        Helper $helper,
        HelperApi $helperApi,
        ManagerInterface $messageManager,
        ?AbstractResource $resource = null,
        ?AbstractDb $resourceCollection = null,
        array $data = [],
        ?DirectoryHelper $directory = null
    ) {
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $paymentLogger,
            $resource,
            $resourceCollection,
            $data,
            $directory
        );
        $this->logger = $logger;
        $this->messageManager = $messageManager;
        $this->helper = $helper;
        $this->helperApi = $helperApi;
    }

    /**
     * Authorize payment
     *
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @param float $amount
     * @return \CanPay\Payment\Model\Payment
     */
    public function authorize(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        return $this;
    }

    /**
     * Void payment
     *
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @return \CanPay\Payment\Model\Payment
     */
    public function void(\Magento\Payment\Model\InfoInterface $payment)
    {
        try {
            $order = $payment->getOrder();
            $intentId = $order->getCanpaypaymentIntentId();
            $transactionId = $payment->getLastTransId();
            if ($intentId && $transactionId) {
                $result = $this->helperApi->paymentReversal($intentId);
                if ($result) {
                    if ($result['code'] == 200) {
                        if (isset($result['message'])) {
                            $this->messageManager->addSuccess(__('CanPay Payment paymentreversal: ' . $result['message']));
                        }
                    } else {
                        if (isset($result['message'])) {
                            $this->messageManager->addError(__('CanPay Payment paymentreversal: ' . $result['message']));
                            $this->logger->error('CanPay_Payment ERROR paymentreversal: ' . $result['message']);
                        }
                    }
                }
            }
        } catch (Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: Transaction was not voided. Message: ' . $e->getMessage());
        }
        return $this;
    }
}

