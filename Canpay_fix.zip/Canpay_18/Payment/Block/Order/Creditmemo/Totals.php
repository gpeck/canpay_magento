<?php

namespace CanPay\Payment\Block\Order\Creditmemo;

use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\Registry;
use CanPay\Payment\Helper\Data as Helper;

class Totals extends \Magento\Sales\Block\Order\Creditmemo\Totals
{
    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param Helper $helper
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Helper $helper,
        array $data = []
    ) {
        parent::__construct($context, $registry, $data);
        $this->helper = $helper;
    }

    /**
     * Initialize order totals array
     *
     * @return $this|Totals
     */
    protected function _initTotals()
    {
        parent::_initTotals();

        if ($this->helper->getEnable()) {
            $tip['tip'] = new \Magento\Framework\DataObject(
                [
                    'code' => 'tip',
                    'field' => 'tip_amount',
                    'value' => $this->helper->getOrderById($this->getCreditmemo()->getOrderId())->getTipAmount(),
                    'label' => __('Tip'),
                ]
            );
            $this->_totals = array_merge(array_splice($this->_totals, 0, 1), $tip, $this->_totals);
        }
        return $this;
    }
}
