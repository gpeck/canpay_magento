<?php

namespace CanPay\Payment\Helper;

use CanPay\Payment\Helper\Data as Helper;
use CanPay\Payment\Model\HTTP\Client\Curl;
use Psr\Log\LoggerInterface;

class Api
{

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var Curl
     */
    protected $curl;

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @param Helper $helper
     * @param Curl $curl
     * @param LoggerInterface $logger
     */
    public function __construct(
        Helper $helper,
        Curl $curl,
        LoggerInterface $logger
    ) {
        $this->helper = $helper;
        $this->curl = $curl;
        $this->logger = $logger;
    }

    /**
     * @return array
     */
    private function getCurlHeaders()
    {
        return [
            'Content-Type' => 'multipart/form-data',
            'user-agent' => 'curl/7.77.0'
        ];
    }

    /**
     * @param $amount
     * @param string $authOnly
     * @return false|mixed|void
     */
    public function getIntentId($amount, string $authOnly = 'false')
    {
        try {
            $this->curl->setHeaders(
                $this->getCurlHeaders()
            );
            $fields = [
                'app_key' => $this->helper->getAppKey(),
                'api_secret' => $this->helper->getApiSecret(),
                'integrator_id' => $this->helper->getIntegratorId(),
                'canpay_internal_version' => $this->helper->getCanPayInternalVersion(),
                'auth_only' => $authOnly,
                'amount' => $amount ? round($amount, 2) : ''
            ];

            $this->curl->post($this->helper->getApiUrl('authorize'), $fields);
            $result = json_decode($this->curl->getBody(),1);

            if ($result) {
                if ($result['code'] == 200) {
                    if (isset($result['data']['intent_id'])) {
                        return $result['data']['intent_id'];
                    }
                } else {
                    $this->logger->error('CanPay_Payment ERROR: ' . $result['message']);
                }
            }
            return false;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: ' . $e->getMessage());
        }
        return false;
    }

    /**
     *
     * @param string $intentId
     * @return string|boolean
     */
    public function getTransactionDetails($intentId)
    {
        try {
            $this->curl->setHeaders(
                $this->getCurlHeaders()
            );
            $fields = [
                'intent_id' => $intentId
            ];

            $this->curl->post($this->helper->getApiUrl('transactiondetails'), $fields);
            $result = json_decode($this->curl->getBody(),1);
            if ($result) {
                if ($result['code'] == 200) {
                    if (isset($result['data'])) {
                        return $result['data'];
                    }
                } else {
                    if (isset($result['message'])) {
                        $this->logger->error('CanPay_Payment ERROR transactiondetails: ' . $result['message']);
                    }
                }
            }
            return false;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: ' . $e->getMessage());
        }
        return false;
    }

    /**
     *
     * @param string $intentId
     * @return array
     */
    public function paymentReversal($intentId)
    {
        try {
            $this->curl->setHeaders(
                $this->getCurlHeaders()
            );
            $fields = [
                'intent_id' => $intentId
            ];

            $this->curl->post($this->helper->getApiUrl('paymentreversal'), $fields);
            $result = json_decode($this->curl->getBody(),1);
            return $result;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: ' . $e->getMessage());
        }
        return false;
    }

    /**
     * @param $reasonType
     * @return mixed|void
     */
    public function getModificationReason($reasonType)
    {
        try {
            $this->curl->setHeaders(
                $this->getCurlHeaders()
            );
            $fields = [
                'reason_type' => $reasonType
            ];
            $this->curl->post($this->helper->getApiUrl('getmodificationreason'), $fields);
            $result = json_decode($this->curl->getBody(),1);
            return $result;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: ' . $e->getMessage());
        }
        return false;
    }

    /**
     * @param $intentId
     * @param $updatedAmount
     * @param $reasonId
     * @param $reasonComment
     * @return mixed|void
     */
    public function transactionUpdate($intentId, $updatedAmount, $reasonId, $reasonComment)
    {
        try {
            $this->curl->setHeaders(
                $this->getCurlHeaders()
            );
            $fields = [
                'intent_id' => $intentId,
                'updated_amount' => $updatedAmount,
                'reason_id' => $reasonId,
                'reason_comment' => $reasonComment
            ];

            $this->curl->post($this->helper->getApiUrl('transactionupdate'), $fields);
            $result = json_decode($this->curl->getBody(),1);
            return $result;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: ' . $e->getMessage());
        }
        return false;
    }

    /**
     * @param $intentId
     * @return mixed|void
     */
    public function modificationHistory($intentId)
    {
        try {
            $this->curl->setHeaders(
                $this->getCurlHeaders()
            );
            $fields = [
                'intent_id' => $intentId
            ];

            $this->curl->post($this->helper->getApiUrl('modificationhistory'), $fields);
            $result = json_decode($this->curl->getBody(),1);
            return $result;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: ' . $e->getMessage());
        }
        return false;
    }

    /**
     * @param $intentId
     * @param $fromDate
     * @param $toDate
     * @return mixed|void
     */
    public function getDashboardData($intentId, $fromDate, $toDate)
    {
        try {
            $this->curl->setHeaders(
                $this->getCurlHeaders()
            );
            $fromDate = $fromDate ? date('Y-m-d', strtotime($fromDate)) : '';
            $toDate = $toDate ? date('Y-m-d', strtotime($toDate)) : '';
            if (!$fromDate && !$toDate) {
                $toDate = date('Y-m-d');
                $fromDate = date('Y-m-d', strtotime('-7 days'));
            } elseif (!$fromDate && $toDate) {
                $fromDate = date('Y-m-d', strtotime($toDate . '-7 days'));
            } elseif ($fromDate && !$toDate) {
                $toDate = date('Y-m-d', strtotime($fromDate . '+7 days'));
            }
            $fields = [
                'intent_id' => $intentId,
                'from_date' => $fromDate,
                'to_date' => $toDate
            ];

            $this->curl->post($this->helper->getApiUrl('dashboard'), $fields);
            $result = json_decode($this->curl->getBody(),1);
            return $result;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: ' . $e->getMessage());
        }
        return false;
    }

    /**
     * @param $intentId
     * @param $fromDate
     * @param $toDate
     * @param $type
     * @param $limit
     * @param $page
     * @return false|mixed
     */
    public function loadMoreTransactionsData($intentId, $fromDate, $toDate, $type, $limit, $page)
    {
        try {
            $this->curl->setHeaders(
                $this->getCurlHeaders()
            );
            $fromDate = $fromDate ? date('Y-m-d', strtotime($fromDate)) : '';
            $toDate = $toDate ? date('Y-m-d', strtotime($toDate)) : '';
            if (!$fromDate && !$toDate) {
                $toDate = date('Y-m-d');
                $fromDate = date('Y-m-d', strtotime('-7 days'));
            } elseif (!$fromDate && $toDate) {
                $fromDate = date('Y-m-d', strtotime($toDate . '-7 days'));
            } elseif ($fromDate && !$toDate) {
                $toDate = date('Y-m-d', strtotime($fromDate . '+7 days'));
            }
            $fields = [
                'intent_id' => $intentId,
                'from_date' => $fromDate,
                'to_date' => $toDate,
                'type' => $type,
                'limit' => $limit,
                'page' => $page
            ];

            $this->curl->post($this->helper->getApiUrl('loadmoretransactions'), $fields);
            $result = json_decode($this->curl->getBody(),1);
            return $result;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: ' . $e->getMessage());
        }
        return false;
    }

    /**
     * @param $intentId
     * @return mixed|void
     */
    public function acceptPayment($intentId)
    {
        try {
            $this->curl->setHeaders(
                $this->getCurlHeaders()
            );
            $fields = [
                'intent_id' => $intentId
            ];

            $this->curl->post($this->helper->getApiUrl('acceptpayment'), $fields);
            $result = json_decode($this->curl->getBody(),1);
            return $result;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: ' . $e->getMessage());
        }
        return false;
    }

    /**
     * @param $intentId
     * @param $fromDate
     * @param $toDate
     * @param $limit
     * @param $page
     * @param $transactionNumber
     * @param $amount
     * @param $updatedAmount
     * @return false|mixed
     */
    public function advancesearchtransactions($intentId, $fromDate, $toDate, $limit, $page, $transactionNumber = null, $amount = null, $updatedAmount = null)
    {
        try {
            $this->curl->setHeaders(
                $this->getCurlHeaders()
            );
            $fromDate = $fromDate ? date('Y-m-d', strtotime($fromDate)) : '';
            $toDate = $toDate ? date('Y-m-d', strtotime($toDate)) : '';
            if (!$fromDate && !$toDate) {
                $toDate = date('Y-m-d');
                $fromDate = date('Y-m-d', strtotime('-7 days'));
            } elseif (!$fromDate && $toDate) {
                $fromDate = date('Y-m-d', strtotime($toDate . '-7 days'));
            } elseif ($fromDate && !$toDate) {
                $toDate = date('Y-m-d', strtotime($fromDate . '+7 days'));
            }
            $fields = [
                'intent_id' => $intentId,
                'from_date' => $fromDate,
                'to_date' => $toDate,
                'limit' => $limit,
                'page' => $page
            ];
            if ($transactionNumber) {
                $fields['transaction_number'] = $transactionNumber;
            }
            if ($amount) {
                $fields['amount'] = $amount;
            }
            if ($updatedAmount) {
                $fields['updated_amount'] = $updatedAmount;
            }

            $this->curl->post($this->helper->getApiUrl('advancesearchtransactions'), $fields);
            $result = json_decode($this->curl->getBody(),1);
            return $result;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: ' . $e->getMessage());
        }
        return false;
    }
}
