<?php

namespace CanPay\Payment\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\Context;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Message\ManagerInterface as MessageManagerInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\InventoryInStorePickupSales\Model\Order\CreateShippingDocument;
use Magento\InventoryInStorePickupSalesApi\Model\IsOrderReadyForPickupInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Sales\Api\ShipmentRepositoryInterface;
use Magento\Sales\Model\Order;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;
use Magento\Sales\Api\OrderPaymentRepositoryInterface;
use CanPay\Payment\Model\Payment;
use Magento\Sales\Api\TransactionRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Backend\Model\Session\Quote as SessionQuote;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Backend\Model\UrlInterface;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const XML_PATH_PAYMENT_CANPAYPAYMENT_ACTIVE = 'payment/canpaypayment/active';
    const XML_PATH_PAYMENT_CANPAYPAYMENT_TITLE = 'payment/canpaypayment/title';
    const XML_PATH_PAYMENT_CANPAYPAYMENT_APP_KEY = 'payment/canpaypayment/app_key';
    const XML_PATH_PAYMENT_CANPAYPAYMENT_API_SECRET = 'payment/canpaypayment/api_secret';
    const XML_PATH_PAYMENT_CANPAYPAYMENT_INTEGRATOR_ID = 'payment/canpaypayment/integrator_id';
    const XML_PATH_PAYMENT_CANPAYPAYMENT_SANDBOX = 'payment/canpaypayment/sandbox';
    const CANPAYPAYMENT_CANPAY_INTERNAL_VERSION = 'Magento';
    const CANPAYPAYMENT_SANDBOX_URL = 'https://sandbox-api.canpaydebit.com/integrator/';
    const CANPAYPAYMENT_URL = 'https://api.canpaydebit.com/integrator/';

    /**
     *
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     *
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;

    /**
     *
     * @var CartRepositoryInterface
     */
    protected $quoteRepository;

    /**
     *
     * @var CheckoutSession
     */
    protected $checkoutSession;

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var OrderPaymentRepositoryInterface
     */
    protected $orderPaymentRepository;

    /**
     *
     * @var TransactionRepositoryInterface
     */
    protected $transactionRepository;

    /**
     *
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     *
     * @var OrderRepositoryInterface
     */
    protected $orderRepository;

    /**
     *
     * @var SessionQuote
     */
    protected $sessionQuote;

    /**
     *
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     *
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     *
     * @var TimezoneInterface
     */
    private $timezone;

    /**
     *
     * @var ShipmentRepositoryInterface
     */
    private $shipmentRepository;

    /**
     *
     * @var CreateShippingDocument
     */
    private $createShippingDocument;

    /**
     *
     * @var InvoiceService
     */
    protected $invoiceService;

    /**
     *
     * @var IsOrderReadyForPickupInterface
     */
    private $isOrderReadyForPickup;

    /**
     *
     * @var MessageManagerInterface
     */
    protected $messageManager;

    /**
     *
     * @var OrderCollectionFactory
     */
    protected $orderCollectionFactory;

    /**
     * @param Context $context
     * @param CustomerSession $customerSession
     * @param CustomerRepositoryInterface $customerRepository
     * @param CartRepositoryInterface $quoteRepository
     * @param CheckoutSession $checkoutSession
     * @param LoggerInterface $logger
     * @param OrderPaymentRepositoryInterface $orderPaymentRepository
     * @param TransactionRepositoryInterface $transactionRepository
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param OrderRepositoryInterface $orderRepository
     * @param SessionQuote $sessionQuote
     * @param StoreManagerInterface $storeManager
     * @param UrlInterface $urlBuilder
     * @param TimezoneInterface $timezone
     * @param ShipmentRepositoryInterface $shipmentRepository
     * @param CreateShippingDocument $createShippingDocument
     * @param InvoiceService $invoiceService
     * @param IsOrderReadyForPickupInterface $isOrderReadyForPickup
     * @param MessageManagerInterface $messageManager
     * @param OrderCollectionFactory $orderCollectionFactory
     */
    public function __construct(
        Context $context,
        CustomerSession $customerSession,
        CustomerRepositoryInterface $customerRepository,
        CartRepositoryInterface $quoteRepository,
        CheckoutSession $checkoutSession,
        LoggerInterface $logger,
        OrderPaymentRepositoryInterface $orderPaymentRepository,
        TransactionRepositoryInterface $transactionRepository,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        OrderRepositoryInterface $orderRepository,
        SessionQuote $sessionQuote,
        StoreManagerInterface $storeManager,
        UrlInterface $urlBuilder,
        TimezoneInterface $timezone,
        ShipmentRepositoryInterface $shipmentRepository,
        CreateShippingDocument $createShippingDocument,
        InvoiceService $invoiceService,
        IsOrderReadyForPickupInterface $isOrderReadyForPickup,
        MessageManagerInterface $messageManager,
        OrderCollectionFactory $orderCollectionFactory
    ) {
        $this->customerSession = $customerSession;
        $this->customerRepository = $customerRepository;
        $this->quoteRepository = $quoteRepository;
        $this->checkoutSession = $checkoutSession;
        $this->logger = $logger;
        $this->orderPaymentRepository = $orderPaymentRepository;
        $this->transactionRepository = $transactionRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->orderRepository = $orderRepository;
        $this->sessionQuote = $sessionQuote;
        $this->storeManager = $storeManager;
        $this->urlBuilder = $urlBuilder;
        $this->timezone = $timezone;
        $this->shipmentRepository = $shipmentRepository;
        $this->createShippingDocument = $createShippingDocument;
        $this->invoiceService = $invoiceService;
        $this->isOrderReadyForPickup = $isOrderReadyForPickup;
        $this->messageManager = $messageManager;
        $this->orderCollectionFactory = $orderCollectionFactory;
        parent::__construct(
            $context
        );
    }

    /**
     * Return module status
     *
     * @return mixed
     */
    public function getEnable()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_PAYMENT_CANPAYPAYMENT_ACTIVE,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Return app_key
     *
     * @return mixed
     */
    public function getAppKey()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_PAYMENT_CANPAYPAYMENT_APP_KEY,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Return api_secret
     *
     * @return mixed
     */
    public function getApiSecret()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_PAYMENT_CANPAYPAYMENT_API_SECRET,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Return integrator_id
     *
     * @return mixed
     */
    public function getIntegratorId()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_PAYMENT_CANPAYPAYMENT_INTEGRATOR_ID,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Return canpay_internal_version
     *
     * @return string
     */
    public function getCanPayInternalVersion()
    {
        return self::CANPAYPAYMENT_CANPAY_INTERNAL_VERSION;
    }

    /**
     * Return Canpay Sandbox
     *
     * @return string
     */
    public function getCanPaySandbox()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_PAYMENT_CANPAYPAYMENT_SANDBOX,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Get API url
     * @param string $path
     * @return string
     */
    public function getApiUrl($path = null)
    {
        if ($this->scopeConfig->getValue(
            self::XML_PATH_PAYMENT_CANPAYPAYMENT_SANDBOX,
            ScopeInterface::SCOPE_STORE
        )) {
            return self::CANPAYPAYMENT_SANDBOX_URL . $path;
        } else {
            return self::CANPAYPAYMENT_URL . $path;
        }
    }

    /**
     *
     * @return boolean
     */
    public function isLoggedIn()
    {
        return $this->customerSession->isLoggedIn();
    }

    /**
     *
     * @return integer
     */
    public function getCustomerId() {
        return $this->customerSession->getId();
    }

    /**
     *
     * @return \Magento\Customer\Api\Data\CustomerInterface|boolean
     */
    public function getCustomerById($customerId) {
        try {
            $customer = $this->customerRepository->getById($customerId);
            return $customer;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: customer was not received. Message: ' . $e->getMessage());
        }
        return false;
    }

    /**
     *
     * @param \Magento\Customer\Api\Data\CustomerInterface $customer
     * @return boolean
     */
    public function saveCustomer($customer) {
        try {
            $this->customerRepository->save($customer);
            return true;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: customer was not saved. Message: ' . $e->getMessage());
        }
        return false;
    }

    /**
     *
     * @return float
     */
    public function getCartAmount()
    {
        return $this->getQuote()->getGrandTotal();
    }

    /**
     *
     * @return \Magento\Quote\Model\Quote
     */
    public function getQuote()
    {
        return $this->checkoutSession->getQuote();
    }

    /**
     *
     * @param integer $quoteId
     * @return \Magento\Quote\Api\Data\CartInterface
     */
    public function getQuoteById($quoteId)
    {
        return $this->quoteRepository->get($quoteId);
    }

    /**
     *
     * @param \Magento\Quote\Api\Data\CartInterface $quote
     * @return void
     */
    public function saveQuote($quote)
    {
        return $this->quoteRepository->save($quote);
    }

    /**
     *
     * @return \Magento\Sales\Api\Data\OrderPaymentInterface[]
     */
    public function getSalesOrderPaymentsWithoutTransaction()
    {
        $this->searchCriteriaBuilder->addFilter('method', Payment::CODE);
        $this->searchCriteriaBuilder->addFilter('last_trans_id', true, 'null');
        $list = $this->orderPaymentRepository->getList(
            $this->searchCriteriaBuilder->create()
        );
        return $list->getItems();
    }

    /**
     *
     * @param int $orderId
     * @return \Magento\Sales\Api\Data\TransactionInterface[]
     */
    public function getTransactionsByOrderId($orderId)
    {
        $this->searchCriteriaBuilder->addFilter('order_id', $orderId);
        $list = $this->transactionRepository->getList(
            $this->searchCriteriaBuilder->create()
        );
        return $list->getItems();
    }

    /**
     * @param $orderIds
     * @return \Magento\Sales\Model\ResourceModel\Order\Collection
     */
    public function getOrdersByIds($orderIds)
    {
        $collection = $this->orderCollectionFactory->create()
            ->addAttributeToSelect('*')
            ->addFieldToFilter('entity_id',
                ['in' => $orderIds]
            );
        return $collection;
    }

    /**
     * @param $orderId
     * @return false|\Magento\Sales\Api\Data\OrderInterface
     */
    public function getOrderById($orderId)
    {
        try {
            $order = $this->orderRepository->get($orderId);
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: order was not reeived. Message: ' . $e->getMessage());
            return false;
        }
        return $order;
    }

    /**
     * @param \Magento\Sales\Api\Data\OrderInterface
     * @return bool
     */
    public function saveOrder($order) {
        try {
            $this->orderRepository->save($order);
            return true;
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: order was not saved. Message: ' . $e->getMessage());
        }
        return false;
    }

    /**
     *
     * @param Order $order
     * @return boolean
     */
    public function isCanPayPayment($order)
    {
        $payment = $order->getPayment();
        $method = $payment->getMethodInstance()->getCode();
        if ($method == Payment::CODE) {
            return true;
        }
        return false;
    }

    /**
     *
     * @param string $intentId
     * @return \Magento\Sales\Api\Data\OrderInterface
     */
    public function getOrderByIntentId($intentId)
    {
        $this->searchCriteriaBuilder->addFilter('canpaypayment_intent_id', $intentId);
        $list = $this->orderRepository->getList(
            $this->searchCriteriaBuilder->create()
        );
        return $list->getLastItem();
    }

    /**
     * @param $currentOrder
     * @return string|void
     */
    public function getOldPaymentMethod($currentOrder)
    {
        if ($currentOrder) {
            return $this->getCurrentOrder()->getPayment()->getMethod();
        }
        return false;
    }

    /**
     * @return false|Order
     */
    public function getCurrentOrder()
    {
        $currentOrder = $this->sessionQuote->getOrder();
        if ($currentOrder && $currentOrder->getId()) {
            return $currentOrder;
        }
        return false;
    }

    /**
     * @param $txnId
     * @return \Magento\Sales\Api\Data\TransactionInterface
     */
    public function getTransactionById($txnId)
    {
        return $this->transactionRepository->get($txnId);
    }

    /**
     * @param $transactionNumber
     * @return \Magento\Sales\Api\Data\TransactionInterface[]
     */
    public function getTransactionByNumber($transactionNumber)
    {
        $this->searchCriteriaBuilder->addFilter('txn_id', $transactionNumber);
        $list = $this->transactionRepository->getList(
            $this->searchCriteriaBuilder->create()
        );
        return $list->getFirstItem();
    }

    /**
     * @param $transactionNumbers
     * @return \Magento\Sales\Api\Data\TransactionInterface[]
     */
    public function getTransactionsByNumbers($transactionNumbers)
    {
        $this->searchCriteriaBuilder->addFilter('txn_id', $transactionNumbers, 'in');
        $list = $this->transactionRepository->getList(
            $this->searchCriteriaBuilder->create()
        );
        return $list->getItems();
    }

    /**
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCurrencySymbol()
    {
        return $this->storeManager->getStore()->getBaseCurrency()->getCurrencySymbol();
    }

    /**
     * @param $orderId
     * @return string
     */
    public function getOrderViewUrl($orderId)
    {
        return $this->urlBuilder->getUrl('sales/order/view/',[
            'order_id' => $orderId
        ]);
    }

    /**
     * @param $orderId
     * @return void
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function fulfillOrder($orderId)
    {
        try {
            $order = $this->getOrderById($orderId);
            $searchCriteria = $this->searchCriteriaBuilder->addFilter('order_id', $orderId);
            $shipments = $this->shipmentRepository->getList($searchCriteria->create());
            $isShipmentCreated = $shipments->getTotalCount() > 0;
            if ($isShipmentCreated === false) {
                $this->createShippingDocument->execute($order);
            }

            $order->setState(\CanPay\Payment\Setup\Patch\Data\AddCompleteFulfilledOrderStatus::ORDER_STATE_COMPLETE_FULFILLED_CODE);
            $order->setStatus(\CanPay\Payment\Setup\Patch\Data\AddCompleteFulfilledOrderStatus::ORDER_STATUS_COMPLETE_FULFILLED_CODE);

            // Add order history item with In-Store Pickup information.
            $time = $this->timezone->formatDateTime(new \DateTime(), \IntlDateFormatter::LONG, \IntlDateFormatter::MEDIUM);
            $history = $order->addCommentToStatusHistory(
                __('Order was pickuped: %1', $time),
                $order->getStatus(),
                true
            );
            $history->setIsCustomerNotified((int)$order->getExtensionAttributes()->getNotificationSent());
            $this->orderRepository->save($order);

        } catch (Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: Change order status. Message: ' . $e->getMessage());
        } catch (LocalizedException $e) {
            $this->messageManager->addError(__('The order is not ready for pickup'));
            $this->logger->error('CanPay_Payment ERROR: Change order status. Message: ' . $e->getMessage());
        }
    }

    /**
     * @param $orderId
     * @return bool
     */
    public function isOrderReadyForPickup($orderId)
    {
        $searchCriteria = $this->searchCriteriaBuilder->addFilter('order_id', $orderId);
        $shipments = $this->shipmentRepository->getList($searchCriteria->create());
        $isShipmentCreated = $shipments->getTotalCount() > 0;
        if ($isShipmentCreated === false) {
            if (!$this->isOrderReadyForPickup->execute($orderId)) {
                return false;
            }
        }
        return true;
    }

    /**
     *
     * @return boolean
     */
    public function reCollectTotals()
    {
        try {
            $this->getQuote()->collectTotals()->save();
        } catch (\Exception $e) {
            return false;
        }
        return true;
    }

    /**
     * @param $quote
     * @return mixed
     */
    public function getTipAmount($quote = null)
    {
        $tipAmount = $quote ? $quote->getTipAmount() : $this->getQuote()->getTipAmount();
        if (!$tipAmount) {
            if ($oldOrder = $this->getCurrentOrder()) {
                $tipAmount = $this->getQuoteById($oldOrder->getQuoteId())->getTipAmount();
            }
        }
        return $tipAmount;
    }
}
