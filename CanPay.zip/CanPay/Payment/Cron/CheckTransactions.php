<?php

namespace CanPay\Payment\Cron;

use Psr\Log\LoggerInterface;
use CanPay\Payment\Helper\Data as Helper;

class CheckTransactions
{
    
    /**
     *
     * @var LoggerInterface
     */
    protected $logger;
    
    /**
     *
     * @var Helper
     */
    protected $helper;
    
    /**
     * 
     * @param LoggerInterface $logger
     * @param Helper $helper
     */
    public function __construct(
        LoggerInterface $logger,
        Helper $helper
    ) {
        $this->logger = $logger;
        $this->helper = $helper;
    }
    
    public function execute()
    {
        if ($this->helper->getEnable()) {
            $payments = $this->helper->getSalesOrderPaymentsWithoutTransaction();
            foreach ($payments as $payment) {
                try {
                    $order = $payment->getOrder();
                    $intentId = $order->getCanpaypaymentIntentId();
                    if ($intentId) {
                        $payment->save();
                    }
                } catch (\Exception $e) {
                    $this->logger->error('CanPay_Payment ERROR: Transaction was not created. Message: ' . $e->getMessage());
                }
            }
        }
    }
}