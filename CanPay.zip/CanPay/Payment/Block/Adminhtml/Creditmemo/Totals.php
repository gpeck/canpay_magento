<?php

namespace CanPay\Payment\Block\Adminhtml\Creditmemo;

use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\Registry;
use Magento\Sales\Helper\Admin;
use CanPay\Payment\Helper\Data as Helper;

class Totals extends \Magento\Sales\Block\Adminhtml\Order\Creditmemo\Totals
{
    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param Admin $adminHelper
     * @param Helper $helper
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Admin $adminHelper,
        Helper $helper,
        array $data = []
    ) {
        parent::__construct($context, $registry, $adminHelper, $data);
        $this->helper = $helper;
    }

    /**
     * Initialize creditmemo totals array
     *
     * @return $this|Totals
     */
    protected function _initTotals()
    {
        parent::_initTotals();

        if ($this->helper->getEnable()) {
            $tip['tip'] = new \Magento\Framework\DataObject(
                [
                    'code' => 'tip',
                    'field' => 'tip_amount',
                    'value' => $this->helper->getOrderById($this->getCreditmemo()->getOrderId())->getTipAmount(),
                    'label' => __('Tip'),
                ]
            );
            $this->_totals = array_merge(array_splice($this->_totals, 0, 1), $tip, $this->_totals);
        }

        return $this;
    }
}
