<?php

namespace CanPay\Payment\Block\Adminhtml\Dashboard;

use CanPay\Payment\Helper\Api as HelperApi;
use Magento\Backend\Block\Template\Context;
use Psr\Log\LoggerInterface;

class Index extends \Magento\Backend\Block\Template
{

    /**
     *
     * @var HelperApi
     */
    protected $helperApi;

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @param Context $context
     * @param HelperApi $helperApi
     * @param LoggerInterface $logger
     * @param array $data
     */
    public function __construct(
        Context $context,
        HelperApi $helperApi,
        LoggerInterface $logger,
        array $data = []
    ) {
        $this->helperApi = $helperApi;
        $this->logger = $logger;
        parent::__construct($context, $data);
    }

    /**
     * @return false|mixed|string
     */
    public function getDashboardData()
    {
        $intentId = $this->helperApi->getIntentId('', 'true');
        if ($intentId) {
            $dashboardData = $this->helperApi->getDashboardData($intentId, false, false);
            if ($dashboardData) {
                if ($dashboardData['code'] == 200) {
                    return isset($dashboardData['data']) ? $dashboardData['data'] : '';
                } else {
                    $this->logger->error('CanPay_Payment ERROR: ' . isset($dashboardData['message']) ? $dashboardData['message'] : 'Dashboard data was not received');
                }
            }
        } else {
            $this->logger->error('CanPay_Payment ERROR: intent_id was not received');
        }
        return false;
    }
}
