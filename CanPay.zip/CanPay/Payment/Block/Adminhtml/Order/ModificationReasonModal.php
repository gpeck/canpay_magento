<?php

namespace CanPay\Payment\Block\Adminhtml\Order;

use CanPay\Payment\Helper\Data as Helper;
use Magento\Backend\Block\Template\Context;

class ModificationReasonModal extends \Magento\Backend\Block\Template
{

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     * @param Context $context
     * @param Helper $helper
     * @param array $data
     */
    public function __construct(
        Context $context,
        Helper $helper,
        array $data = []
    ) {
        $this->helper = $helper;
        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function getEditUrl()
    {
        return $this->getUrl('sales/order_edit/start',[
            'order_id' => $this->getOrder()->getId()
        ]);
    }

    /**
     * @return \Magento\Sales\Model\Order
     */
    public function getCurrentOrder()
    {
        return $this->helper->getCurrentOrder();
    }
}
