<?php

namespace CanPay\Payment\Block\Adminhtml\Order\Create\Totals;

use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Backend\Model\Session\Quote;
use Magento\Sales\Model\AdminOrder\Create;
use Magento\Sales\Helper\Data as SalesHelper;
use Magento\Sales\Model\Config as SalesConfig;
use Magento\Tax\Model\Config as TaxConfig;

class Grandtotal extends \Magento\Sales\Block\Adminhtml\Order\Create\Totals\Grandtotal
{
    /**
     * Template
     *
     * @var string
     */
    protected $_template = 'CanPay_Payment::order/create/totals/grandtotal.phtml';

    /**
     * Tax config
     *
     * @var Config
     */
    protected $_taxConfig;

    /**
     * @param Context $context
     * @param Quote $sessionQuote
     * @param Create $orderCreate
     * @param PriceCurrencyInterface $priceCurrency
     * @param SalesHelper $salesData
     * @param SalesConfig $salesConfig
     * @param TaxConfig $taxConfig
     * @param array $data
     */
    public function __construct(
        Context $context,
        Quote $sessionQuote,
        Create $orderCreate,
        PriceCurrencyInterface $priceCurrency,
        SalesHelper $salesData,
        SalesConfig $salesConfig,
        TaxConfig $taxConfig,
        array $data = []
    ) {
        $this->_taxConfig = $taxConfig;
        parent::__construct(
            $context,
            $sessionQuote,
            $orderCreate,
            $priceCurrency,
            $salesData,
            $salesConfig,
            $taxConfig,
            $data
        );
    }
}
