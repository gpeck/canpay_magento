<?php

namespace CanPay\Payment\Model;

use CanPay\Payment\Api\Repository\TipRepositoryInterface;
use CanPay\Payment\Helper\Data as Helper;
use Magento\Framework\Webapi\Rest\Request;
use Psr\Log\LoggerInterface;

class TipRepository implements TipRepositoryInterface
{
    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var Request
     */
    protected $request;

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @param Helper $helper
     * @param Request $request
     * @param LoggerInterface $logger
     */
    public function __construct(
        Helper $helper,
        Request $request,
        LoggerInterface $logger
    ) {
        $this->helper = $helper;
        $this->request = $request;
        $this->logger = $logger;
    }

    /**
     * @return array|bool[]
     */
    public function applyTip()
    {
        $post = json_decode($this->request->getContent(), true);
        $tipAmount = isset($post['tip_amount']) ? $post['tip_amount'] : '';
        $quoteId = isset($post['quote_id']) ? $post['quote_id'] : '';

        if ($quoteId && $tipAmount) {
            try {
                $quote = $this->helper->getQuoteById($quoteId);
                $quote->setTipAmount($tipAmount);
                $this->helper->saveQuote($quote);
                $result = [
                    'success' => true,
                ];
            } catch (\Exception $e) {
                $this->logger->error('CanPay_Payment ERROR: tip was not saved. Message: ' . $e->getMessage());
                $result = [
                    'success' => false
                ];
            }
        } else {
            $this->logger->error('CanPay_Payment ERROR: quote_id or tip_amount was not received');
            $result = [
                'success' => false
            ];
        }
        return json_encode($result);
    }

    /**
     * @return false|string
     */
    public function cancelTip()
    {
        $post = json_decode($this->request->getContent(), true);
        $quoteId = isset($post['quote_id']) ? $post['quote_id'] : '';

        if ($quoteId) {
            try {
                $quote = $this->helper->getQuoteById($quoteId);
                $quote->setTipAmount(null);
                $this->helper->saveQuote($quote);
                $result = [
                    'success' => true,
                ];
            } catch (\Exception $e) {
                $this->logger->error('CanPay_Payment ERROR: tip was not canceled. Message: ' . $e->getMessage());
                $result = [
                    'success' => false
                ];
            }
        } else {
            $this->logger->error('CanPay_Payment ERROR: quote_id was not received');
            $result = [
                'success' => false
            ];
        }
        return json_encode($result);
    }
}
