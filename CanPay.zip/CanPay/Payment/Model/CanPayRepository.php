<?php

namespace CanPay\Payment\Model;

use CanPay\Payment\Api\Repository\CanPayRepositoryInterface;
use CanPay\Payment\Helper\Data as Helper;
use Magento\Framework\Webapi\Rest\Request;
use CanPay\Payment\Helper\Api as HelperApi;
use Psr\Log\LoggerInterface;
use Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface as TransactionBuilderInterface;
use Magento\Sales\Model\Order\Payment\Transaction;

class CanPayRepository implements CanPayRepositoryInterface
{
    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var Request
     */
    protected $request;

    /**
     *
     * @var HelperApi
     */
    protected $helperApi;

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var TransactionBuilderInterface
     */
    protected $transactionBuilder;

    /**
     * @param Helper $helper
     * @param Request $request
     * @param HelperApi $helperApi
     * @param LoggerInterface $logger
     * @param TransactionBuilderInterface $transactionBuilder
     */
    public function __construct(
        Helper $helper,
        Request $request,
        HelperApi $helperApi,
        LoggerInterface $logger,
        TransactionBuilderInterface $transactionBuilder
    ) {
        $this->helper = $helper;
        $this->request = $request;
        $this->helperApi = $helperApi;
        $this->logger = $logger;
        $this->transactionBuilder = $transactionBuilder;
    }

    /**
     *
     * @return string
     */
    public function saveAuthId()
    {
        $result = [];
        try {
            $post = json_decode($this->request->getContent(), true);
            if (isset($post['auth_id'])) {
                $authId = $post['auth_id'];
                $customerId = $this->helper->getCustomerId();
                if ($customerId && $customer = $this->helper->getCustomerById($customerId)) {
                    $customer->setCustomAttribute('canpaypayment_auth_id', $authId);
                    $result = $this->helper->saveCustomer($customer);
                }
                $result = [
                    'success' => true,
                ];
            }
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: canpaypayment_auth_id was not saved. Message: ' . $e->getMessage());
            $result = [
                'success' => false,
                'message' => 'Error processing payment, please try again later'
            ];
        }
        return json_encode($result);
    }

   /**
    *
    * @return string
    */
    public function getCanPayConfig()
    {
        $result = [];
        $intentId = $this->helperApi->getIntentId($this->getCartAmount() - $this->helper->getQuote()->getTipAmount());

        if ($intentId) {
            $this->saveIntentIdToQuote($intentId);
        } else {
            $this->logger->error('CanPay_Payment ERROR: intent_id was not received');
            $result = [
                'success' => false,
                'message' => 'Error processing payment, please try again later'
            ];
            return json_encode($result);
        }
        $customerId = $this->helper->getCustomerId();
        if ($customerId && $customer = $this->helper->getCustomerById($customerId)) {
            if ($customer->getCustomAttribute('canpaypayment_auth_id')) {
                $authId = $customer->getCustomAttribute('canpaypayment_auth_id')->getValue();
            }
        }
        $result = [
            'success' => true,
            'auth_id' => isset($authId) ? $authId : '',
            'intent_id' => isset($intentId) ? $intentId : ''
        ];
        return json_encode($result);
    }

    /**
     *
     * @return string|boolean
     */
    public function saveIntentIdToQuote($intentId)
    {
        $result = [];
        try {
            $quote = $this->helper->getQuote();
            $quote->setCanpaypaymentIntentId($intentId);
            $this->helper->saveQuote($quote);
            $result = [
                'success' => true,
            ];
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: canpaypayment_intent_id was not saved. Message: ' . $e->getMessage());
            $result = [
                'success' => false,
                'message' => 'Error processing payment, please try again later'
            ];
        }
        return $result;
    }

    /**
     *
     * @return float
     */
    public function getCartAmount()
    {
        return $this->helper->getCartAmount();
    }

    /**
     *
     * @return string
     */
    public function checkSignature()
    {
        $result = [];
        try {
            $post = json_decode($this->request->getContent(), true);
            $response = isset($post['response']) ? $post['response'] : '';
            $signature = isset($post['signature']) ? $post['signature'] : '';
            if ($response && $signature) {
                $apiSecret = $this->helper->getApiSecret();
                $khash = hash_hmac('sha256', $response, $apiSecret);
                if ($signature == $khash) {
                    $result = [
                        'success' => true,
                    ];
                } else {
                    $this->logger->error('CanPay_Payment ERROR: signature was not validated');
                    $result = [
                        'success' => false,
                        'message' => 'Error processing payment, please try again later'
                    ];
                }
            }
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: signature was not validated. Message: ' . $e->getMessage());
            $result = [
                'success' => false,
                'message' => 'Error processing payment, please try again later'
            ];
        }
        return json_encode($result);
    }

    /**
     *
     * @return string
     */
    public function callback()
    {
        $result = [];
        try {
            $post = $this->request->getRequestData();
            $intentId = isset($post['intent_id']) ? $post['intent_id'] : '';
            $order = $this->helper->getOrderByIntentId($intentId);
            if ($order) {
                $payment = $order->getPayment();
                $transactions = $this->helper->getTransactionsByOrderId($order->getId());

                if ($transactionDetails = $this->helperApi->getTransactionDetails($intentId)) {
                    if (count($transactions) > 0) {
                        foreach ($transactions as $transaction) {
                            if ($transactionDetails['transaction_number']) {
                                $transaction->setAdditionalInformation(\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS, $transactionDetails);
                                $payment->save();
                                $transaction->save();
                            }
                        }
                    } else {
                        if ($transactionDetails['transaction_number']) {
                            $payment->setTransactionId($transactionDetails['transaction_number']);
                            $payment->setIsTransactionPending(false);
                            $formatedPrice = $order->getBaseCurrency()->formatTxt($order->getGrandTotal());
                            $message = __('The authorized amount is %1.', $formatedPrice);
                            $transaction = $this->transactionBuilder->setPayment($payment)
                                ->setOrder($order)
                                ->setTransactionId($payment->getTransactionId())
                                ->setAdditionalInformation(
                                    [\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS => $transactionDetails]
                                )
                                ->setFailSafe(true)
                                ->build(Transaction::TYPE_AUTH);
                            $payment->addTransactionCommentsToOrder($transaction, $message);
                            $payment->setIsTransactionClosed(false);
                            $order->setCanpaypaymentStatus($transactionDetails['status']);
                            $payment->save();
                            $transaction->save();
                            $order->save();
                        }
                    }
                    $result = [
                        'success' => true,
                    ];
                }
            } else {
                $result = [
                    'success' => false,
                    'message' => 'CanPay_Payment ERROR: Order with intent_id equals ' . $intentId . ' does not exist'
                ];
            }
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: Transaction was not created. Message: ' . $e->getMessage());
            $result = [
                'success' => false,
                'message' => 'CanPay_Payment ERROR: Transaction was not created. Message: ' . $e->getMessage()
            ];
        }
        return json_encode($result);
    }

    /**
     * @return false|string
     */
    public function getModificationReason()
    {
        $result = [];
        try {
            $post = $this->request->getRequestData();
            $reasonType = isset($post['reason_type']) ? $post['reason_type'] : '';
            if ($reasonType == 'unchange') {
                $modificationReasonIncrease = $this->helperApi->getModificationReason('increase');
                $modificationReasonDecrease = $this->helperApi->getModificationReason('decrease');
                if (($modificationReasonIncrease['code'] == 200) && ($modificationReasonDecrease['code'] == 200)) {
                    $result = [
                        'success' => true,
                        'modification_reason' => array_merge($modificationReasonIncrease['data'], $modificationReasonDecrease['data'])
                    ];
                } else {
                    $result = [
                        'success' => false,
                        'message' => $modificationReasonIncrease['message'] . ' ' . $modificationReasonDecrease['message']
                    ];
                }
            } else {
                $modificationReason = $this->helperApi->getModificationReason($reasonType);
                if ($modificationReason) {
                    if ($modificationReason['code'] == 200) {
                        $result = [
                            'success' => true,
                            'modification_reason' => isset($modificationReason['data']) ? $modificationReason['data'] : ''
                        ];
                    } else {
                        $result = [
                            'success' => false,
                            'message' => isset($modificationReason['message']) ? $modificationReason['message'] : ''
                        ];
                    }
                }
            }
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: Modification reason was not received. Message: ' . $e->getMessage());
            $result = [
                'success' => false,
                'message' => 'CanPay_Payment ERROR: Modification reason was not received. Message: ' . $e->getMessage()
            ];
        }
        return json_encode($result);
    }

    /**
     * @return false|string
     */
    public function saveModificationReasonId()
    {
        $result = [];
        try {
            $post = json_decode($this->request->getContent(), true);
            $modificationReasonId = isset($post['modification_reason_id']) ? $post['modification_reason_id'] : '';
            $modificationReasonComment = isset($post['modification_reason_comment']) ? $post['modification_reason_comment'] : '';
            $orderId = isset($post['order_id']) ? $post['order_id'] : '';

            if ($modificationReasonId && $orderId) {
                $order = $this->helper->getOrderById($orderId);
                $order->setCanpaypaymentModificationReasonId($modificationReasonId);
                if ($modificationReasonComment) {
                    $order->setCanpaypaymentModificationReasonComment($modificationReasonComment);
                }
                $this->helper->saveOrder($order);
                $result = [
                    'success' => true,
                ];
            }
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: modification_reason_id was not saved. Message: ' . $e->getMessage());
            $result = [
                'success' => false,
                'message' => 'CanPay_Payment ERROR: modification_reason_id was not saved. Message: ' . $e->getMessage()
            ];
        }
        return json_encode($result);
    }

    /**
     * @return false|string
     */
    public function getDashboardData()
    {
        $result = [];
        try {
            $post = $this->request->getRequestData();
            $intentId = $this->helperApi->getIntentId('', 'true');
            if ($intentId) {
                $fromDate = isset($post['from_date']) ? $post['from_date'] : '';
                $toDate = isset($post['to_date']) ? $post['to_date'] : '';
                $dashboardData = $this->helperApi->getDashboardData($intentId, $fromDate, $toDate);
                if ($dashboardData) {
                    if ($dashboardData['code'] == 200) {
                        if (isset($dashboardData['data'])) {
                            foreach ($dashboardData['data']['pre_load_transactions']['pending_and_unpaid_transactions'] as $key => $pendingAndUnpaidTransaction) {
                                if (!($transactionData = $this->getOrderData($pendingAndUnpaidTransaction))) {
                                    unset($dashboardData['data']['pre_load_transactions']['pending_and_unpaid_transactions'][$key]);
                                } else {
                                    $dashboardData['data']['pre_load_transactions']['pending_and_unpaid_transactions'][$key] = $transactionData;
                                }
                            }
                            $dashboardData['data']['pre_load_transactions']['pending_and_unpaid_transactions'] = array_values($dashboardData['data']['pre_load_transactions']['pending_and_unpaid_transactions']);

                            foreach ($dashboardData['data']['pre_load_transactions']['awaiting_consumer_approval_transactions'] as $key => $awaitingConsumerApprovalTransaction) {
                                if (!($transactionData = $this->getOrderData($awaitingConsumerApprovalTransaction))) {
                                    unset($dashboardData['data']['pre_load_transactions']['awaiting_consumer_approval_transactions'][$key]);
                                } else {
                                    $dashboardData['data']['pre_load_transactions']['awaiting_consumer_approval_transactions'][$key] = $transactionData;
                                }
                            }
                            $dashboardData['data']['pre_load_transactions']['awaiting_consumer_approval_transactions'] = array_values($dashboardData['data']['pre_load_transactions']['awaiting_consumer_approval_transactions']);

                            foreach ($dashboardData['data']['pre_load_transactions']['approved_transactions'] as $key => $approvedTransaction) {
                                if (!($transactionData = $this->getOrderData($approvedTransaction))) {
                                    unset($dashboardData['data']['pre_load_transactions']['approved_transactions'][$key]);
                                } else {
                                    $dashboardData['data']['pre_load_transactions']['approved_transactions'][$key] = $transactionData;
                                }
                            }
                            $dashboardData['data']['pre_load_transactions']['approved_transactions'] = array_values($dashboardData['data']['pre_load_transactions']['approved_transactions']);

                            foreach ($dashboardData['data']['pre_load_transactions']['declined_transactions'] as $key => $declinedTransaction) {
                                if (!($transactionData = $this->getOrderData($declinedTransaction))) {
                                    unset($dashboardData['data']['pre_load_transactions']['declined_transactions'][$key]);
                                } else {
                                    $dashboardData['data']['pre_load_transactions']['declined_transactions'][$key] = $transactionData;
                                }
                            }
                            $dashboardData['data']['pre_load_transactions']['declined_transactions'] = array_values($dashboardData['data']['pre_load_transactions']['declined_transactions']);
                        }
                        $result = [
                            'success' => true,
                            'data' => isset($dashboardData['data']) ? $dashboardData['data'] : '',
                            'message' => isset($dashboardData['message']) ? $dashboardData['message'] : ''
                        ];
                    } else {
                        $result = [
                            'success' => false,
                            'message' => isset($dashboardData['message']) ? $dashboardData['message'] : ''
                        ];
                    }
                }
            } else {
                $this->logger->error('CanPay_Payment ERROR: intent_id was not received');
                $result = [
                    'success' => false,
                    'message' => 'CanPay_Payment ERROR: intent_id was not received'
                ];
            }
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: Dashboard data was not received. Message: ' . $e->getMessage());
            $result = [
                'success' => false,
                'message' => 'CanPay_Payment ERROR: Dashboard data was not received. Message: ' . $e->getMessage()
            ];
        }
        return json_encode($result);
    }

    /**
     * @param $transactionData
     * @return false|string
     */
    public function getOrderData($transactionData)
    {
        $order = $this->helper->getOrderByIntentId($transactionData['intent_id']);
        if ($order && $order->getId()) {
            $transactionData['order_view_url'] = $this->helper->getOrderViewUrl($order->getId());
            $transactionData['first_name'] = $order->getCustomerFirstname() ? $order->getCustomerFirstname() : '';
            $transactionData['last_name'] = $order->getCustomerLastname() ? $order->getCustomerLastname() : '';
            $transactionData['phone'] = $order->getBillingAddress()->getTelephone() ? $order->getBillingAddress()->getTelephone() : '';
            $transactionData['email'] = $order->getCustomerEmail() ? $order->getCustomerEmail() : '';
            return $transactionData;
        }
        return false;
    }

    /**
     * @return false|string
     */
    public function loadMoreTransactionsData()
    {
        $result = [];
        try {
            $post = $this->request->getRequestData();
            $intentId = $this->helperApi->getIntentId('', 'true');
            if ($intentId) {
                $fromDate = isset($post['from_date']) ? $post['from_date'] : '';
                $toDate = isset($post['to_date']) ? $post['to_date'] : '';
                $type = isset($post['type']) ? $post['type'] : '';
                $limit = isset($post['limit']) ? $post['limit'] : '';
                $page = isset($post['page']) ? $post['page'] : '';
                $moreTransactionsData = $this->helperApi->loadMoreTransactionsData($intentId, $fromDate, $toDate, $type, $limit, $page);

                if ($moreTransactionsData) {
                    if ($moreTransactionsData['code'] == 200) {
                        if (isset($moreTransactionsData['data']['data'])) {
                            foreach ($moreTransactionsData['data']['data'] as $key => $transaction) {
                                if (!($transactionData = $this->getOrderData($transaction))) {
                                    unset($moreTransactionsData['data']['data'][$key]);
                                } else {
                                    $moreTransactionsData['data']['data'][$key] = $transactionData;
                                }
                            }
                            $moreTransactionsData['data']['data'] = array_values($moreTransactionsData['data']['data']);
                        }

                        $result = [
                            'success' => true,
                            'data' => isset($moreTransactionsData['data']) ? $moreTransactionsData['data'] : '',
                            'message' => isset($moreTransactionsData['message']) ? $moreTransactionsData['message'] : ''
                        ];
                    } else {
                        $result = [
                            'success' => false,
                            'message' => isset($moreTransactionsData['message']) ? $moreTransactionsData['message'] : ''
                        ];
                    }
                }
            } else {
                $this->logger->error('CanPay_Payment ERROR: intent_id was not received');
                $result = [
                    'success' => false,
                    'message' => 'CanPay_Payment ERROR: intent_id was not received'
                ];
            }
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: More transactions data was not received. Message: ' . $e->getMessage());
            $result = [
                'success' => false,
                'message' => 'CanPay_Payment ERROR: More transactions data was not received. Message: ' . $e->getMessage()
            ];
        }
        return json_encode($result);
    }

    /**
     * @return false|string
     */
    public function getModificationReasonType()
    {
        $result = [];
        try {
            $post = $this->request->getRequestData();
            $quoteId = isset($post['quote_id']) ? $post['quote_id'] : '';
            if ($quoteId) {
                $quote = $this->helper->getQuoteById($quoteId);
                $oldOrder = $this->helper->getOrderById($quote->getOldOrderId());
                if ($quote && $oldOrder) {
                    if ($quote->getGrandTotal() > $oldOrder->getGrandTotal()) {
                        $result['modification_reason_type'] = 'increase';
                    } elseif ($quote->getGrandTotal() < $oldOrder->getGrandTotal()) {
                        $result['modification_reason_type'] = 'decrease';
                    } else {
                        $result['modification_reason_type'] = 'unchange';
                    }
                    $result['success'] = true;
                } else {
                    $result = [
                        'success' => false,
                        'message' => 'CanPay_Payment ERROR: Cannot get Transaction Modification Reason Type.'
                    ];
                }
            } else {
                $result = [
                    'success' => false,
                    'message' => 'CanPay_Payment ERROR: Cannot get Transaction Modification Reason Type.'
                ];
            }
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: Cannot get Transaction Modification Reason Type. Message: ' . $e->getMessage());
            $result = [
                'success' => false,
                'message' => 'CanPay_Payment ERROR: Cannot get Transaction Modification Reason Type. Message: ' . $e->getMessage()
            ];
        }
        return json_encode($result);
    }
}
