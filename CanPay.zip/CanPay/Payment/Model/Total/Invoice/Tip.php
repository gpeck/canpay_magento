<?php

namespace CanPay\Payment\Model\Total\Invoice;

use Magento\Sales\Model\Order\Invoice\Total\AbstractTotal;
use CanPay\Payment\Helper\Data as Helper;

class Tip extends AbstractTotal
{
    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     * @param Helper $helper
     * @param array $data
     */
    public function __construct(
        Helper $helper,
        array $data = []
    ) {
        $this->helper = $helper;
        parent::__construct($data);
    }

    /**
     * @param \Magento\Sales\Model\Order\Invoice $invoice
     * @return $this
     */
    public function collect(\Magento\Sales\Model\Order\Invoice $invoice)
    {
        parent::collect($invoice);
        if ($this->helper->getEnable() && $invoice->getOrderId() ) {
            $tip = $this->helper->getOrderById($invoice->getOrderId())->getTipAmount();
            $invoice->setGrandTotal($invoice->getGrandTotal() + $tip);
            $invoice->setBaseGrandTotal($invoice->getBaseGrandTotal() + $tip);
        }

        return $this;
    }
}
