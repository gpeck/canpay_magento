<?php

namespace CanPay\Payment\Model\Total\Quote;

use Magento\Quote\Model\Quote\Address\Total\AbstractTotal;
use Magento\Quote\Model\Quote;
use Magento\Quote\Api\Data\ShippingAssignmentInterface;
use Magento\Quote\Model\Quote\Address\Total;
use CanPay\Payment\Helper\Data as Helper;

class Tip extends AbstractTotal
{
    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     * @param Helper $helper
     */
    public function __construct(
        Helper $helper
    ) {
        $this->helper = $helper;
    }

    /**
     *
     * @param Quote $quote
     * @param ShippingAssignmentInterface $shippingAssignment
     * @param Total $total
     * @return \CanPay\Payment\Model\Total\Quote\Tip
     */
    public function collect(
        Quote $quote,
        ShippingAssignmentInterface $shippingAssignment,
        Total $total
    ) {
        parent::collect($quote, $shippingAssignment, $total);
        if ($this->helper->getEnable()) {
            $address = $shippingAssignment->getShipping()->getAddress();
            $items = $this->_getAddressItems($address);
            if (!count($items)) {
                return $this;
            }

            $tipAmount = $quote->getTipAmount();
            $total->addTotalAmount($this->getCode(), $tipAmount);
            $total->addBaseTotalAmount($this->getCode(), $tipAmount);
        }

        return $this;
    }

    /**
     *
     * @param Quote $quote
     * @param Total $total
     * @return array
     */
    public function fetch(
        Quote $quote,
        Total $total
    ) {
        if ($this->helper->getEnable()) {
            $tipAmount = $this->helper->getTipAmount($quote);
            return [
                'code'  => 'tip_amount',
                'title' => __('Tip'),
                'value' => $tipAmount
            ];
        }
        return parent::fetch($quote,$total);
    }
}
