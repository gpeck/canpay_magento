<?php

namespace CanPay\Payment\Model\Total\Creditmemo;

use Magento\Tax\Model\Config;
use Magento\Sales\Model\Order\Creditmemo\Total\AbstractTotal;
use CanPay\Payment\Helper\Data as Helper;


class Tip extends AbstractTotal
{
    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     * @param Helper $helper
     * @param array $data
     */
    public function __construct(
        Helper $helper,
        array $data = []
    ) {
        parent::__construct($data);
        $this->helper = $helper;
    }

    /**
     * Collect tip
     *
     * @param \Magento\Sales\Model\Order\Creditmemo $creditmemo
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function collect(\Magento\Sales\Model\Order\Creditmemo $creditmemo)
    {
        parent::collect($creditmemo);
        if ($this->helper->getEnable() && $creditmemo->getOrderId() ) {
            $tip = $this->helper->getOrderById($creditmemo->getOrderId())->getTipAmount();
            $creditmemo->setGrandTotal($creditmemo->getGrandTotal() + $tip);
            $creditmemo->setBaseGrandTotal($creditmemo->getBaseGrandTotal() + $tip);
        }

        return $this;
    }
}
