<?php

namespace CanPay\Payment\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use CanPay\Payment\Helper\Data as Helper;

class AdditionalConfigVars implements ConfigProviderInterface
{
    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     * @param Helper $helper
     */
    public function __construct(
        Helper $helper
    ) {
        $this->helper = $helper;
    }

    /**
     * @return array
     */
    public function getConfig()
    {
        $additionalVariables['isCanPaymentEnable'] = $this->helper->getEnable();
        return $additionalVariables;
    }
}
