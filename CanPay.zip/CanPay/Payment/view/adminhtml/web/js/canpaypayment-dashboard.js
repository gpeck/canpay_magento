define([
    'jquery',
    'mage/translate',
    'Magento_Ui/js/modal/modal',
    'mage/calendar',
    'loader',
    'domReady!'
], function ($, $t, modal) {
    'use strict';

    $.widget('mage.canpaypaymentDashboard', {
        options: {
            pendingAndUnpaidTransactionsCount : 4,
            awaitingConsumerApprovalTransactionsCount : 4,
            approvedTransactionsCount : 4,
            declinedTransactionsCount : 4,
            limit : 1000,
            countEntries : $('#count-entries').val(),
            pageFrom : $('.view-more-popup tr.enable').first().attr('data-elem-key'),
            pageTo : $('.view-more-popup tr.enable').last().attr('data-elem-key'),
            pageAll : $('.view-more-popup tr').last().attr('data-elem-key'),
            pageNumber : $('.page-current').val(),
            pageAllSearch: 0,
            transactionNumbers: [],
        },

        /**
         * @protected
         */
        _create: function () {
            var self = this;

            $('.from-date, .to-date').calendar({
                changeMonth: true,
                changeYear: true,
                showButtonPanel: true,
                dateFormat:"mm/dd/yyyy",
                currentText: $t('Go Today'),
                closeText: $t('Close'),
                showWeek: true
            });

            $('.search-button').click(function() {
                $('body').trigger('processStart');
                self._getDashboardData($('.from-date').val(), $('.to-date').val());
            });
            $('.view-more').click(function() {
                self._prepareViewMoreDialog(this);
            });
            self._setPaginationEvents();
            $('body').trigger('processStart');
            self._getDashboardData($('.from-date').val(), $('.to-date').val());
        },

        _getDashboardData: function (fromDate, toDate) {
            var self = this;

            self._removeMessages();

            $('.transactions-data').attr('data-page-number', 1);
            let dashboardDataUrl = '/rest/V1/canpay/get-dashboard-data',
                requestData = JSON.stringify({
                    'from_date': fromDate,
                    'to_date': toDate
                });
            $.ajax({
                method: 'POST',
                url: dashboardDataUrl,
                async: true,
                dataType: 'json',
                contentType: "application/json",
                data: requestData,
                beforeSend: function(xhr){}
            }).done (function (result) {
                result = JSON.parse(result);
                let dashboardData = result['data'] ? result['data'] : null,
                    message = result['message'] ? result['message'] : '';
                $('.transactions-pending table tbody').html('');
                $('.transactions-awaiting-consumer-approval table tbody').html('');
                $('.transactions-approved table tbody').html('');
                $('.transactions-declined table tbody').html('');
                if (result['success']) {
                    if (dashboardData) {
                        $('.transaction-to-expire-content.today .transaction-to-expire-total').val(dashboardData['number_of_transaction_to_expire']['today']);
                        $('.transaction-to-expire-content.tommorow .transaction-to-expire-total').val(dashboardData['number_of_transaction_to_expire']['tomorrow']);
                        $('.transaction-to-expire-content.today .day-after-tomorrow').val(dashboardData['number_of_transaction_to_expire']['dayaftertomorrow']);
                        let pendingAndUnpaidTransactions = dashboardData['pre_load_transactions']['pending_and_unpaid_transactions'],
                            awaitingConsumerApprovalTransactions = dashboardData['pre_load_transactions']['awaiting_consumer_approval_transactions'],
                            approvedTransactions = dashboardData['pre_load_transactions']['approved_transactions'],
                            declinedTransactions = dashboardData['pre_load_transactions']['declined_transactions'];

                        self._showViewMoreButton(pendingAndUnpaidTransactions, $('.transactions-pending'), self.options.pendingAndUnpaidTransactionsCount, $('.from-date').val(), $('.to-date').val(), $('.transactions-pending').find('.table-wrapper').attr('data-type'), self.options.limit, 1);
                        self._showViewMoreButton(awaitingConsumerApprovalTransactions, $('.transactions-awaiting-consumer-approval'), self.options.awaitingConsumerApprovalTransactionsCount, $('.from-date').val(), $('.to-date').val(), $('.transactions-awaiting-consumer-approval').find('.table-wrapper').attr('data-type'), self.options.limit, 1);
                        self._showViewMoreButton(approvedTransactions, $('.transactions-approved'), self.options.approvedTransactionsCount, $('.from-date').val(), $('.to-date').val(), $('.transactions-approved').find('.table-wrapper').attr('data-type'), self.options.limit, 1);
                        self._showViewMoreButton(declinedTransactions, $('.transactions-declined'), self.options.declinedTransactionsCount, $('.from-date').val(), $('.to-date').val(), $('.transactions-declined').find('.table-wrapper').attr('data-type'), self.options.limit, 1);
                        if (pendingAndUnpaidTransactions.length > 0) {
                            for (var i = 0; i < pendingAndUnpaidTransactions.length; i++) {
                                if (i < 4) {
                                    self._addPendingAndUnpaidTransaction(pendingAndUnpaidTransactions[i], $('.transactions-pending'), i);
                                }
                            }
                        } else {
                            self._addTransactionsNotFoundMessage($('.transactions-pending table tbody'));
                        }

                        if (awaitingConsumerApprovalTransactions.length > 0) {
                            for (var i = 0; i < awaitingConsumerApprovalTransactions.length; i++) {
                                if (i < 4) {
                                    self._addAwaitingConsumerApprovalTransaction(awaitingConsumerApprovalTransactions[i], $('.transactions-awaiting-consumer-approval'), i);
                                }
                            }
                        } else {
                            self._addTransactionsNotFoundMessage($('.transactions-awaiting-consumer-approval table tbody'));
                        }

                        if (approvedTransactions.length > 0) {
                            for (var i = 0; i < approvedTransactions.length; i++) {
                                if (i < 4) {
                                    self._addApprovedTransaction(approvedTransactions[i], $('.transactions-approved'), i);
                                }
                            }
                        } else {
                            self._addTransactionsNotFoundMessage($('.transactions-approved table tbody'));
                        }

                        if (declinedTransactions.length > 0) {
                            for (var i = 0; i < declinedTransactions.length; i++) {
                                if (i < 4) {
                                    self._addDeclinedTransaction(declinedTransactions[i], $('.transactions-declined'), i);
                                }
                            }
                        } else {
                            self._addTransactionsNotFoundMessage($('.transactions-declined table tbody'));
                        }
                        $('.search').append('<div class="success-message">' + message + '</div>');
                    }
                } else {
                    $('.search').append('<div class="error-message">' + message + '</div>');
                    $('.view-more').remove();
                }
                $('body').trigger('processStop');
            });
        },

        /**
         *
         * @param transaction
         * @param elem
         * @param i
         * @private
         */
        _addPendingAndUnpaidTransaction: function (transaction, elem, i) {
            var self = this;
            var html = '<tr data-intent-id="' + transaction['intent_id'] + '" data-elem-key="' + (i+1) + '"';
            if (i >= self.options.countEntries) {
                html += 'class="disable"';
            } else {
                html += 'class="enable"';
            }
            html += '><td class="transaction-number"><a href="' + transaction['order_view_url'] + '">' + transaction['transaction_number'] + '</a></td>\n' +
                '<td class="transaction-date">' + transaction['transaction_date'] + '</td>\n' +
                '<td class="orginal-amount">' + self.options.currencySymbol + transaction['orginal_amount'] + '</td>\n' +
                '<td class="orginal-tip-amount">' + self.options.currencySymbol + transaction['orginal_tip_amount'] + '</td>\n' +
                '<td class="expiry-date-for-book-now">' + transaction['expiry_date_for_book_now'] + '</td>\n' +
                '<td class="status tooltip"><span class="tooltip-toggle">' + transaction['status'] + '</span><span class="tooltip-content">' + transaction['status'] + '</span></td>\n' +
                '<td class="first-name">' + transaction['first_name'] + '</td>\n' +
                '<td class="last-name">' + transaction['last_name'] + '</td>\n' +
                '<td class="phone">' + transaction['phone'] + '</td>\n' +
                '<td class="email">' + transaction['email'] + '</td>\n' +
                '</tr>';
            $(elem).find('table tbody').append(html);
            self.options.transactionNumbers.push(transaction['transaction_number']);
        },

        /**
         *
         * @param transaction
         * @param elem
         * @param i
         * @private
         */
        _addAwaitingConsumerApprovalTransaction: function (transaction, elem, i) {
            var self = this;
            var html = '<tr data-intent-id="' + transaction['intent_id'] + '" data-elem-key="' + (i+1) + '"';
            if (i >= self.options.countEntries) {
                html += 'class="disable"';
            } else {
                html += 'class="enable"';
            }
            html += '><td class="transaction-number"><a href="' + transaction['order_view_url'] + '">' + transaction['transaction_number'] + '</a></td>\n' +
                '<td class="transaction-date">' + transaction['transaction_date'] + '</td>\n' +
                '<td class="updated-amount">' + self.options.currencySymbol + transaction['updated_amount'] + '</td>\n' +
                '<td class="last-updated-tip-amount">' + self.options.currencySymbol + transaction['last_updated_tip_amount'] + '</td>\n' +
                '<td class="time-left-for-approval"></td>\n' +
                '<td class="first-name">' + transaction['first_name'] + '</td>\n' +
                '<td class="last-name">' + transaction['last_name'] + '</td>\n' +
                '<td class="phone">' + transaction['phone'] + '</td>\n' +
                '<td class="email">' + transaction['email'] + '</td>';
            if (transaction['status'] == 'Expired') {
                html += transaction['status'];
            } else {
                html += transaction['time_left_for_approval']
            }
            html += '</td>\n' +
                '</tr>';
            $(elem).find('table tbody').append(html);
            self._addTransactionsAmountStyles($(elem).find('table tbody tr').last(), transaction);
            self.options.transactionNumbers.push(transaction['transaction_number']);
        },

        /**
         *
         * @param transaction
         * @param elem
         * @param i
         * @private
         */
        _addApprovedTransaction: function (transaction, elem, i) {
            var self = this;
            var html = '<tr data-intent-id="' + transaction['intent_id'] + '" data-elem-key="' + (i+1) + '"';
            if (i >= self.options.countEntries) {
                html += 'class="disable"';
            } else {
                html += 'class="enable"';
            }
            html += '><td class="transaction-number"><a href="' + transaction['order_view_url'] + '">' + transaction['transaction_number'] + '</a></td>\n' +
                '<td class="transaction-date">' + transaction['transaction_date'] + '</td>\n' +
                '<td class="updated-amount">' + self.options.currencySymbol + transaction['updated_amount'] + '</td>\n' +
                '<td class="last-updated-tip-amount">' + self.options.currencySymbol + transaction['last_updated_tip_amount'] + '</td>\n' +
                '<td class="expiry-date-for-book-now">' + transaction['expiry_date_for_book_now'] + '</td>\n' +
                '<td class="first-name">' + transaction['first_name'] + '</td>\n' +
                '<td class="last-name">' + transaction['last_name'] + '</td>\n' +
                '<td class="phone">' + transaction['phone'] + '</td>\n' +
                '<td class="email">' + transaction['email'] + '</td>\n' +
                '</tr>';
            $(elem).find('table tbody').append(html);
            self._addTransactionsAmountStyles($(elem).find('table tbody tr').last(), transaction);
            self.options.transactionNumbers.push(transaction['transaction_number']);
        },

        /**
         *
         * @param transaction
         * @param elem
         * @param i
         * @private
         */
        _addDeclinedTransaction: function (transaction, elem, i) {
            var self = this;
            var html = '<tr data-intent-id="' + transaction['intent_id'] + '" data-elem-key="' + (i+1) + '"';
            if (i >= self.options.countEntries) {
                html += 'class="disable"';
            } else {
                html += 'class="enable"';
            }
            html += '><td class="transaction-number"><a href="' + transaction['order_view_url'] + '">' + transaction['transaction_number'] + '</a></td>\n' +
                '<td class="transaction-date">' + transaction['transaction_date'] + '</td>\n' +
                '<td class="updated-amount">' + self.options.currencySymbol + transaction['updated_amount'] + '</td>\n' +
                '<td class="last-updated-tip-amount">' + self.options.currencySymbol + transaction['last_updated_tip_amount'] + '</td>\n' +
                '<td class="first-name">' + transaction['first_name'] + '</td>\n' +
                '<td class="last-name">' + transaction['last_name'] + '</td>\n' +
                '<td class="phone">' + transaction['phone'] + '</td>\n' +
                '<td class="email">' + transaction['email'] + '</td>\n' +
                '</tr>';
            $(elem).find('table tbody').append(html);
            self._addTransactionsAmountStyles($(elem).find('table tbody tr').last(), transaction);
            self.options.transactionNumbers.push(transaction['transaction_number']);
        },

        /**
         *
         * @param elem
         * @param fromDate
         * @param toDate
         * @param type
         * @param limit
         * @param page
         * @private
         */
        _loadMoreTransactionsData: function (elem, fromDate, toDate, type, limit, page) {
            var self = this;

            self._removeMessages();

            $('.view-more-popup .search-wrapper input').val('');

            let loadMoreTransactionsDataUrl = '/rest/V1/canpay/load-more-transactions-data',
                requestData = JSON.stringify({
                    'from_date': fromDate,
                    'to_date': toDate,
                    'type': type,
                    'limit': limit,
                    'page': page
                });
            $.ajax({
                method: 'POST',
                url: loadMoreTransactionsDataUrl,
                async: true,
                dataType: 'json',
                contentType: "application/json",
                data: requestData,
                beforeSend: function(xhr){}
            }).done (function (result) {
                result = JSON.parse(result);
                let moreTransactionsData = result['data'] && result['data']['data'] ? result['data']['data'] : null,
                    message = result['message'] ? result['message'] : '';
                if (result['success']) {
                    if (moreTransactionsData) {
                        if (moreTransactionsData.length > 0) {
                            for (var i = 0; i < moreTransactionsData.length; i++) {
                                if (type == 'Pending And Unpaid') {
                                    self._addPendingAndUnpaidTransaction(moreTransactionsData[i], elem, i);
                                } else if (type == 'Awaiting Consumer Approval') {
                                    self._addAwaitingConsumerApprovalTransaction(moreTransactionsData[i], elem, i);
                                } else if (type == 'Approved') {
                                    self._addApprovedTransaction(moreTransactionsData[i], elem, i);
                                } else if (type == 'Declined') {
                                    self._addDeclinedTransaction(moreTransactionsData[i], elem, i);
                                }
                            }
                            $('.show-search').append('<div class="success-message">' + message + '</div>');
                        }
                        self._setFirstPage();
                        self._changePageData();
                        self._checkPointer();
                    }
                } else {
                    $('.show-search').append('<div class="error-message">' + message + '</div>');
                    $('.view-more').remove();
                }
                $('body').trigger('processStop');
            });
        },

        /**
         *
         * @param transactions
         * @param elem
         * @param itemCount
         * @private
         */
        _showViewMoreButton: function (transactions, elem, itemCount, fromDate, toDate, type, limit, page) {
            var self = this;
            $('body').trigger('processStart');
            $(elem).find('.view-more').remove();
            let loadMoreTransactionsDataUrl = '/rest/V1/canpay/load-more-transactions-data',
                requestData = JSON.stringify({
                    'from_date': fromDate,
                    'to_date': toDate,
                    'type': type,
                    'limit': limit,
                    'page': page
                });
            $.ajax({
                method: 'POST',
                url: loadMoreTransactionsDataUrl,
                async: true,
                dataType: 'json',
                contentType: "application/json",
                data: requestData,
                beforeSend: function(xhr){}
            }).done (function (result) {
                result = JSON.parse(result);
                let moreTransactionsData = result['data'] && result['data']['data'] ? result['data']['data'] : null,
                    message = result['message'] ? result['message'] : '';
                if (result['success']) {
                    if (moreTransactionsData) {
                        if (moreTransactionsData.length > itemCount) {
                            if ($(elem).find('.view-more').length == 0) {
                                $(elem).find('.transactions-data-header-wrapper').append('<div class="view-more">\n' +
                                    ' <button title="' + $t('View more') + '" type="button" class="view-more-button">\n' +
                                    '     <span>' + $t('View more') + '</span> \n' +
                                    ' </button></div>');
                            }
                            $(elem).find('.view-more').click(function() {
                                self._prepareViewMoreDialog(this);
                            });
                        }
                    }
                }
                $('body').trigger('processStop');
            });
        },

        /**
         *
         * @param date
         * @returns {string}
         * @private
         */
        _formatDateToString: function (date) {
            var dd = (date.getDate() < 10 ? '0' : '') + date.getDate();
            var MM = ((date.getMonth() + 1) < 10 ? '0' : '') + (date.getMonth() + 1);
            var yyyy = date.getFullYear();
        return (MM + "-" + dd + "-" + yyyy);
        },

        /**
         *
         * @param elem
         * @private
         */
        _prepareViewMoreDialog: function (elem) {
            var self = this;
            this.options.dialog = {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                modalClass: 'view-more-popup',
                title: $.mage.__('Transaction Pending'),
                buttons: []
            };
            modal(this.options.dialog, $('#view-more-modal'));
            $('body').trigger('processStart');
            $('.view-more-popup .modal-header h1').html($(elem).parents('.transactions-data-header-wrapper').find('header').html());
            $('.view-more-popup .transactions').html($(elem).parents('.transactions-data').find('.table-wrapper').clone());
            $('.view-more-popup .transactions .table-wrapper').attr('data-type', $(elem).parents('.transactions-data').find('.table-wrapper').attr('data-type'));

            $('.view-more-popup').find('.table-wrapper tbody').html('');
            self._loadMoreTransactionsData($('.view-more-popup').find('.table-wrapper'), $('.from-date').val(), $('.to-date').val(), $(elem).parents('.transactions-data').find('.table-wrapper').attr('data-type'), self.options.limit, 1);
            $('#view-more-modal').modal('openModal');
        },

        /**
         *
         * @private
         */
        _displayTransactions: function () {
            var self = this;
            $('.view-more-popup .transactions .table-wrapper tbody tr').each(function() {
                if (($(this).attr('data-elem-key') > (self.options.pageNumber - 1) * self.options.countEntries) && ($(this).attr('data-elem-key') <= self.options.pageNumber * self.options.countEntries)) {
                    $(this).removeClass('disable').addClass('enable');
                } else {
                    $(this).removeClass('enable').addClass('disable');
                }
            });
        },

        /**
         *
         * @private
         */
        _displayTransactionsSearch: function () {
            var self = this;
            $('.view-more-popup .transactions .table-wrapper tbody tr.enable').each(function(i, elem) {
                if ((i+1 > (self.options.pageNumber - 1) * self.options.countEntries) && (i+1 <= self.options.pageNumber * self.options.countEntries)) {
                    $(this).removeClass('disable').addClass('enable');
                } else {
                    $(this).removeClass('enable').addClass('disable');
                }
            });
        },

        /**
         *
         * @private
         */
        _changePageData: function () {
            var self = this;
            self.options.pageFrom = (self.options.pageNumber - 1) * self.options.countEntries + 1;
            self.options.pageTo = self.options.pageFrom + $('.view-more-popup tr.enable').length - 1;
            self.options.pageAll = $('.view-more-popup tr').last().attr('data-elem-key');
            $('.view-more-popup .page-from').html(self.options.pageFrom);
            $('.view-more-popup .page-to').html(self.options.pageTo);
            $('.view-more-popup .page-all').html(self.options.pageAll);
            if ($('.page-filter-all-wrapper').length > 0) {
                $('.page-filter-all-wrapper').remove();
            }
        },

        /**
         *
         * @private
         */
        _changePageDataSearh: function () {
            var self = this;
            if ($('.view-more-popup tr.enable').length == 0) {
                self.options.pageFrom = 0;
                self.options.pageTo = 0
            } else {
                self.options.pageFrom = (self.options.pageNumber - 1) * self.options.countEntries + 1;
                self.options.pageTo = self.options.pageFrom + $('.view-more-popup tr.enable').length - 1;
            }
            self.options.pageAll = $('.view-more-popup tr').last().attr('data-elem-key');
            $('.view-more-popup .page-from').html(self.options.pageFrom);
            $('.view-more-popup .page-to').html(self.options.pageTo);
            $('.view-more-popup .page-all').html(self.options.pageAllSearch);
            var filterHtml = '<span class="page-filter-all-wrapper"> (filtered from\n' +
                '                    <span class="page-filter-all">' + self.options.pageAll + '</span>\n' +
                '                    total entries)\n' +
                '                </span>';
            if ($('.page-filter-all-wrapper').length > 0) {
                $('.page-filter-all').html(self.options.pageAll);
            } else {
                $('.view-more-popup .pagination .show').append(filterHtml);
            }
        },

        /**
         *
         * @param elemSearch
         * @param list
         * @private
         */
        _searchTransactionPopup: function (elemSearch, list) {
            var self = this;
            var value = $(elemSearch).val().toLowerCase().trim();
            var v = value.split("%");
            self.options.pageAllSearch = 0;
            if (v[0] !== '') {
                $(list).each(function(j,elem) {
                    var showElem = true;
                    $.each(v, function(i, x) {
                        if (x !== '') {
                            if (showElem) {
                                if (($(elem).find('td.transaction-number').text().toLowerCase().indexOf(x) > -1)
                                    || ($(elem).find('.transaction-date').text().toLowerCase().indexOf(x) > -1)
                                    || ($(elem).find('.orginal-amount').text().toLowerCase().indexOf(x) > -1)
                                    || ($(elem).find('.first-name').text().toLowerCase().indexOf(x) > -1)
                                    || ($(elem).find('.last-name').text().toLowerCase().indexOf(x) > -1)
                                    || ($(elem).find('.phone').text().toLowerCase().indexOf(x) > -1)
                                    || ($(elem).find('.email').text().toLowerCase().indexOf(x) > -1)
                                ) {
                                    showElem = true;
                                } else {
                                    showElem = false;
                                }
                            }
                        }
                    });
                    if (showElem) {
                        $(this).removeClass('disable').addClass('enable');
                        self.options.pageAllSearch += 1;
                    } else {
                        $(this).removeClass('enable').addClass('disable');
                    }
                });
                self._displayTransactionsSearch();
                self._changePageDataSearh();
            } else {
                self._displayTransactions();
                self._changePageData();
            }
        },

        /**
         *
         * @private
         */
        _setFirstPage: function () {
            var self = this;
            self.options.pageNumber = 1;
            $('.view-more-popup .page-current').val(1);
        },

        /**
         *
         * @private
         */
        _setPaginationEvents: function () {
            var self = this;
            $('.action-next').click(function() {
                self._removeMessages();
                self.options.pageNumber = parseInt(self.options.pageNumber) + 1;

                if ((!self.options.pageAllSearch && ($('.view-more-popup .search-wrapper input').val() == '') && (self.options.pageNumber <= Math.ceil(self.options.pageAll / self.options.countEntries)))
                    || (self.options.pageAllSearch && self.options.pageNumber <= Math.ceil(self.options.pageAllSearch / self.options.countEntries))) {
                    $('.view-more-popup .page-current').val(self.options.pageNumber);
                    self._displayTransactions();
                    self._searchTransactionPopup($('.view-more-popup .search-wrapper input'), $('.view-more-popup .transactions .table-wrapper tbody tr'));
                } else {
                    self.options.pageNumber = parseInt(self.options.pageNumber) - 1;
                }
                self._checkPageAllEmptyMessage();
                self._checkPointer();
            });
            $('.action-previous').click(function() {
                self._removeMessages();
                if (self.options.pageNumber > 1) {
                    self.options.pageNumber = parseInt(self.options.pageNumber) - 1;
                    $('.view-more-popup .page-current').val(self.options.pageNumber);
                    self._displayTransactions();
                    self._searchTransactionPopup($('.view-more-popup .search-wrapper input'), $('.view-more-popup .transactions .table-wrapper tbody tr'));
                }
                self._checkPageAllEmptyMessage();
                self._checkPointer();
            });
            $('#count-entries').change(function() {
                self._removeMessages();
                self.options.countEntries = $('#count-entries').val();
                if (self.options.pageAll < self.options.countEntries * self.options.pageNumber) {
                    self._setFirstPage();
                }
                self._displayTransactions();
                self._searchTransactionPopup($('.view-more-popup .search-wrapper input'), $('.view-more-popup .transactions .table-wrapper tbody tr'));
                self._checkPageAllEmptyMessage();
                self._checkPointer();
            });
            $( "#view-more-modal .search-wrapper input" ).keyup(function() {
                self._removeMessages();
                self._setFirstPage();
                self._searchTransactionPopup(this, $('.view-more-popup .transactions .table-wrapper tbody tr'));
                self._checkPageAllEmptyMessage();
                self._checkPointer();
            });
        },

        /**
         *
         * @private
         */
        _checkPointer: function () {
            var self = this;
            if ((!self.options.pageAllSearch && ($('.view-more-popup .search-wrapper input').val() == '') && ((self.options.pageNumber + 1) <= Math.ceil(self.options.pageAll/self.options.countEntries)))
                || (self.options.pageAllSearch && (self.options.pageNumber + 1) <= Math.ceil(self.options.pageAllSearch/self.options.countEntries))) {
                $('.action-next').removeClass('pointer-disable').addClass('pointer-enable');
            } else {
                $('.action-next').removeClass('pointer-enable').addClass('pointer-disable');
            }
            if (self.options.pageNumber == 1) {
                $('.action-previous').removeClass('pointer-enable').addClass('pointer-disable');
            } else {
                $('.action-previous').removeClass('pointer-disable').addClass('pointer-enable');
            }
        },

        /**
         *
         * @private
         */
        _removeMessages: function () {
            if ($('.canpaypayment-dashboard-index .error-message').length > 0) {
                $('.canpaypayment-dashboard-index .error-message').remove();
            }

            if ($('.canpaypayment-dashboard-index .success-message').length > 0) {
                $('.canpaypayment-dashboard-index .success-message').remove();
            }
        },

        /**
         *
         * @private
         */
        _checkPageAllEmptyMessage: function () {
            if ($('.view-more-popup .transactions .table-wrapper tbody tr.enable').length == 0) {
                var html = '<tr class="transactions-not-found"><td colspan="' + $('.view-more-popup .transactions .table-wrapper thead th').length + '" class="transactions_empty">' + $t('No matching records found') + '</td></tr>';
                $('.view-more-popup .transactions .table-wrapper tbody .transactions-not-found').remove();
                $('.view-more-popup .transactions .table-wrapper tbody').append(html);
            } else {
                $('.view-more-popup .transactions .table-wrapper tbody .transactions-not-found').remove();
            }
        },

        /**
         *
         * @param elem
         * @private
         */
        _addTransactionsNotFoundMessage: function (elem) {
            var html = '<tr class="transactions-not-found"><td colspan="' + $(elem).parents('table').find('thead th').length + '" class="transactions_empty">' + $t('No Record Found') + '</td></tr>'
            $(elem).append(html);
        },

        /**
         *
         * @param elem
         * @param transaction
         * @private
         */
        _addTransactionsAmountStyles: function (elem, transaction) {
            var self = this;
            let updatedAmountHtml = '',
                updatedTipAmountHtml = '';
            if (transaction['orginal_amount'] > transaction['updated_amount']) {
                updatedAmountHtml += '<div class="text-danger-wrapper"><span class="text-danger"> ' + self.options.currencySymbol + transaction['updated_amount'] + ' </span><span class="arrow-down">&#8595;</span></div>'
                $(elem).find('.updated-amount').html(updatedAmountHtml);
            } else if (transaction['orginal_amount'] < transaction['updated_amount']) {
                updatedAmountHtml += '<div class="text-success-wrapper"><span class="text-success"> ' + self.options.currencySymbol + transaction['updated_amount'] + ' </span><span class="arrow-up">&#8593;</span></div>'
                $(elem).find('.updated-amount').html(updatedAmountHtml);
            }
            if (transaction['orginal_tip_amount'] > transaction['last_updated_tip_amount']) {
                updatedTipAmountHtml += '<div class="text-danger-wrapper"><span class="text-danger"> ' + self.options.currencySymbol + transaction['last_updated_tip_amount'] + ' </span><span class="arrow-down">&#8595;</span></div>'
                $(elem).find('.last-updated-tip-amount').html(updatedTipAmountHtml);
            } else if (transaction['orginal_tip_amount'] < transaction['last_updated_tip_amount']) {
                updatedTipAmountHtml += '<div class="text-success-wrapper"><span class="text-success"> ' + self.options.currencySymbol + transaction['last_updated_tip_amount'] + ' </span><span class="arrow-up">&#8593;</span></div>'
                $(elem).find('.last-updated-tip-amount').html(updatedTipAmountHtml);
            }
        },
    });
    return $.mage.canpaypaymentDashboard;
});
