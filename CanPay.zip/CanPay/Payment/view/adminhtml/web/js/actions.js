define([
    "jquery",
    'uiGridColumnsActions'
], function($, actions) {
    'use strict';
    if ($('body').hasClass('sales-order-index')) {
        return actions.extend({
            defaults: {
                draggable: true
            }
        });
    } else {
        return actions;
    }
    return actions;
});
