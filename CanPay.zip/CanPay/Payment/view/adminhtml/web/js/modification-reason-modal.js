define([
    'jquery',
    'Magento_Ui/js/modal/modal',
    'jquery/ui',
    'mage/translate'
], function ($, modal) {
    'use strict';

    $.widget('mage.modificationReasonModal', {
        options: {},

        /**
         * @protected
         */
        _create: function () {
            var self = this;
            this._prepareDialog();
            $('input[type="radio"][name="modification_reason_type"]').change(function() {
                if ($(this).prop('checked') == true) {
                    $('body').trigger('processStart');
                    self._getModificationReason(this.value);
                }
            });
        },

        submitOrder: function () {
            if (jQuery('#modification-reason-popup-modal .error-message').length == 0) {
                var $editForm = jQuery('#edit_form');
                $editForm.trigger('processStart');
                $editForm.trigger('submitOrder');
            }
        },

        /**
         * Prepare modal
         * @protected
         */
        _prepareDialog: function () {
            var self = this;
            this.options.dialog = {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                modalClass: 'modification-reason-popup',
                title: '',
                buttons: [{
                    text: $.mage.__('Ok'),
                    'class': 'order-edit-add-modification-reason action-primary',

                    /** @inheritdoc */
                    click: function () {
                        if (!$('input[name="modification_reason_type"]').is(':checked')) {
                            if ($('#modification-reason-type-error').length == 0) {
                                $('.field-modification-reason-type').append('<label for="field-modification-reason-type" class="mage-error" id="modification-reason-type-error">' + $.mage.__('This is a required field.') + '</label>');
                            }
                        } else {
                            if ($('#modification-reason-type-error').length > 0) {
                                $('#modification-reason-type-error').remove();
                            }
                        }
                        if (!$('#modification-reason option:selected').length) {
                            if ($('#modification-reason-error').length == 0) {
                                $('.field-modification-reason').append('<label for="field-modification-reason" class="mage-error" id="modification-reason-error">' + $.mage.__('This is a required field.') + '</label>');
                            }
                        } else {
                            if ($('#modification-reason-error').length > 0) {
                                $('#modification-reason-error').remove();
                            }
                        }
                            if ($('#modification-reason-comment').length > 0 && $('#modification-reason-comment').val() == '') {
                            if ($('#modification-reason-comment-error').length == 0) {
                                $('#modification-reason-comment').after('<label for="modification-reason-comment" class="mage-error" id="modification-reason-comment-error">' + $.mage.__('This is a required field.') + '</label>');
                            }
                        } else {
                            if ($('#modification-reason-comment-error').length > 0) {
                                $('#modification-reason-comment-error').remove();
                            }
                        }
                        if ($('#modification-reason-popup-modal').find('.mage-error').length == 0) {
                            this.closeModal();
                            self._saveModificationReason($('#modification-reason').val(), $('#modification-reason-comment').val());
                            self.submitOrder();
                        }
                    }
                }]
            };
            modal(this.options.dialog, $('#modification-reason-popup-modal'));
        },

        _getModificationReason: function (reasonType) {
            var self = this;
            $('#modification-reason-popup-modal #modification-reason-form .error-message').remove();
            let modificationReasonUrl = '/rest/V1/canpay/get-modification-reason',
                requestData = JSON.stringify({
                    'reason_type': reasonType,
                });
            $.ajax({
                method: 'POST',
                url: modificationReasonUrl,
                async: false,
                dataType: 'json',
                contentType: "application/json",
                data: requestData,
                beforeSend: function(xhr){}
            }).done (function (result) {
                result = JSON.parse(result);
                let modificationReason = result['modification_reason'] ? result['modification_reason'] : null,
                    message = result['message'] ? result['message'] : '';
                if (result['success']) {
                    if (modificationReason) {
                        $('#modification-reason').html('');
                        modificationReason.forEach((element) => {
                            $('#modification-reason').append('<option value=' + element['id'] + '>' + element['reason'] + ' (' + element['reason_type'] + ')' + '</option>');
                        });
                    }
                    $('#modification-reason').append('<option class="custom-reason-option" value="custom">Custom reason</option>');
                    if ($('#modification-reason-form').find('.field-modification-reason-comment').length > 0) {
                        $('.field-modification-reason-comment').remove();
                    }
                    $('#modification-reason').change(function() {
                        if (this.value == 'custom') {
                            if ($('#modification-reason-form').find('.field-modification-reason-comment').length == 0) {
                                $('#modification-reason-form').append('<div class="admin__field field field-modification-reason-comment required _required">\n' +
                                    '    <label class="label admin__field-label" for="modification-reason-comment"><span>Modification reason comment</span></label>\n' +
                                    '    <div class="admin__field-control control">\n' +
                                    '        <textarea id="modification-reason-comment" name="modification-reason-comment" class="admin-field admin__control-textarea" rows="10"></textarea>\n' +
                                    '    </div>\n' +
                                    '</div>');
                            }
                        } else {
                            if ($('#modification-reason-form').find('.field-modification-reason-comment').length > 0) {
                                $('.field-modification-reason-comment').remove();
                            }
                        }
                    });
                    $('#modification-reason-type-error').remove();
                    $('#modification-reason-error').remove();
                } else {
                    $('#modification-reason-popup-modal #modification-reason-form').prepend('<span class="error-message">' + message + '</span>');
                }
                $('body').trigger('processStop');
            });
        },

        _saveModificationReason: function (modificationReasonId, modificationReasonComment) {
            let self = this,
                saveModificationReasonUrl = '/rest/V1/canpay/save-modification-reason-id',
                requestData = JSON.stringify({
                    'modification_reason_id': modificationReasonId,
                    'modification_reason_comment': modificationReasonComment,
                    'order_id': this.options.oldOrderId,
                    'form_key': window.FORM_KEY
                });
            $.ajax({
                method: 'POST',
                url: saveModificationReasonUrl,
                async: false,
                dataType: 'json',
                contentType: "application/json",
                data: requestData,
                beforeSend: function(xhr){}
            }).done (function (result) {});
        }
    });

    return $.mage.modificationReasonModal;
});
