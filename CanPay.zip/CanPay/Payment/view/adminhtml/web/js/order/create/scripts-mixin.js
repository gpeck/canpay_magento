define(
    [
        'jquery',
        'Magento_Ui/js/modal/confirm',
        'Magento_Ui/js/modal/alert',
        'mage/template',
        'text!Magento_Sales/templates/order/create/shipping/reload.html',
        'text!Magento_Sales/templates/order/create/payment/reload.html',
        'mage/translate',
        'prototype',
        'Magento_Catalog/catalog/product/composite/configure',
        'Magento_Ui/js/lib/view/utils/async',
    ],
    function (jQuery, confirm, alert, template, shippingTemplate, paymentTemplate) {
        'use strict';

        return function () {
            var STORE_PICKUP_METHOD = 'instore_pickup',
                SOURCES_FIELD_SELECTOR = '#shipping_form_pickup_location_source',
                SAME_AS_BILLING_SELECTOR = '#order-shipping_same_as_billing',
                CUSTOMER_SHIPPING_ADDRESS_ID_SELECTOR = '#order-shipping_address_customer_address_id',
                CUSTOMER_ADDRESS_SAVE_IN_ADDRESS_BOOK_SELECTOR = '#order-shipping_address_save_in_address_book',
                IN_STORE_PICKUP_CHECKBOX_SELECTOR = '#s_method_instore_pickup';

            /**
             * initialize method override
             *
             * @param {String} method
             */
            window.AdminOrder.prototype.initialize = function (data) {
                if (!data) data = {};
                this.loadBaseUrl = false;
                this.customerId = data.customer_id ? data.customer_id : false;
                this.storeId = data.store_id ? data.store_id : false;
                this.quoteId = data['quote_id'] ? data['quote_id'] : false;
                this.currencyId = false;
                this.currencySymbol = data.currency_symbol ? data.currency_symbol : '';
                this.addresses = data.addresses ? data.addresses : $H({});
                this.shippingAsBilling = data.shippingAsBilling ? data.shippingAsBilling : false;
                this.gridProducts = $H({});
                this.gridProductsGift = $H({});
                this.billingAddressContainer = '';
                this.shippingAddressContainer = '';
                this.isShippingMethodReseted = data.shipping_method_reseted ? data.shipping_method_reseted : false;
                this.overlayData = $H({});
                this.giftMessageDataChanged = false;
                this.productConfigureAddFields = {};
                this.productPriceBase = {};
                this.collectElementsValue = true;
                this.isOnlyVirtualProduct = false;
                this.excludedPaymentMethods = [];
                this.summarizePrice = true;
                this.selectAddressEvent = false;
                this.shippingTemplate = template(shippingTemplate, {
                    data: {
                        title: jQuery.mage.__('Shipping Method'),
                        linkText: jQuery.mage.__('Get shipping methods and rates')
                    }
                });
                this.paymentTemplate = template(paymentTemplate, {
                    data: {
                        title: jQuery.mage.__('Payment Method'),
                        linkText: jQuery.mage.__('Get available payment methods')
                    }
                });
                this.storePickupData = [];

                jQuery.async('#order-items', (function () {
                    this.dataArea = new OrderFormArea('data', $(this.getAreaId('data')), this);
                    this.itemsArea = Object.extend(new OrderFormArea('items', $(this.getAreaId('items')), this), {
                        addControlButton: function (button) {
                            var controlButtonArea = $(this.node).select('.actions')[0];
                            if (typeof controlButtonArea != 'undefined') {
                                var buttons = controlButtonArea.childElements();
                                for (var i = 0; i < buttons.length; i++) {
                                    if (buttons[i].innerHTML.include(button.getLabel())) {
                                        return;
                                    }
                                }
                                button.insertIn(controlButtonArea, 'top');
                            }
                        }
                    });

                    var searchButtonId = 'add_products',
                        searchButton = new ControlButton(jQuery.mage.__('Add Products'), searchButtonId),
                        searchAreaId = this.getAreaId('search');
                    searchButton.onClick = function () {
                        $(searchAreaId).show();
                        var el = this;
                        window.setTimeout(function () {
                            el.remove();
                        }, 10);
                    };

                    jQuery.async('#order-items .admin__page-section-title', (function () {
                        this.dataArea.onLoad = this.dataArea.onLoad.wrap(function (proceed) {
                            proceed();
                            this._parent.itemsArea.setNode($(this._parent.getAreaId('items')));
                            this._parent.itemsArea.onLoad();
                        });

                        this.itemsArea.onLoad = this.itemsArea.onLoad.wrap(function (proceed) {
                            proceed();
                            if ($(searchAreaId) && !jQuery('#' + searchAreaId).is(':visible') && !$(searchButtonId)) {
                                this.addControlButton(searchButton);
                            }
                        });
                        this.areasLoaded();
                        this.itemsArea.onLoad();

                    }).bind(this));

                }).bind(this));

                jQuery('#edit_form')
                    .on('submitOrder', function () {
                        jQuery(this).trigger('realOrder');
                    })
                    .on('realOrder', this._realSubmit.bind(this));
            };

            /**
             * Display sources dropdown field;
             * And vice-versa
             *
             * @param {Boolean} isStorePickup
             */
            function setStorePickupMethod(isStorePickup) {
                var sourcesInput = jQuery(SOURCES_FIELD_SELECTOR),
                    shippingAddressSaveInAddressBook = jQuery(CUSTOMER_ADDRESS_SAVE_IN_ADDRESS_BOOK_SELECTOR);

                if (isStorePickup) {
                    shippingAddressSaveInAddressBook.prop('checked', false);
                    sourcesInput.show();

                    return;
                }
                window.order.disableShippingAddress(jQuery(SAME_AS_BILLING_SELECTOR).prop('checked'));
                sourcesInput.hide();
            }

            /**
             * Verify is store pickup delivery method is checked.
             */
            function isStorePickupSelected() {
                var storePickupCheckbox = jQuery(IN_STORE_PICKUP_CHECKBOX_SELECTOR);

                return storePickupCheckbox.length && storePickupCheckbox.prop('checked');
            }

            /**
             * Always disable unwanted shipping address fields in case store pickup is selected.
             */
            window.AdminOrder.prototype.disableShippingAddress =
                window.AdminOrder.prototype.disableShippingAddress.wrap(function (proceed, flag) {
                    var shippingAddressId = jQuery(CUSTOMER_SHIPPING_ADDRESS_ID_SELECTOR),
                        theSameAsBillingCheckBox = jQuery(SAME_AS_BILLING_SELECTOR),
                        shippingAddressSaveInAddressBook = jQuery(CUSTOMER_ADDRESS_SAVE_IN_ADDRESS_BOOK_SELECTOR);

                    proceed(flag);

                    if (isStorePickupSelected()) {
                        shippingAddressId.prop('disabled', true);
                        theSameAsBillingCheckBox.prop('disabled', true);
                        shippingAddressSaveInAddressBook.prop('disabled', true);
                    }
                });

            /**
             * Set shipping method override
             *
             * @param {String} method
             */
            window.AdminOrder.prototype.setShippingMethod = function (method) {
                var data = {},
                    areas = [
                        'shipping_method',
                        'totals',
                        'billing_method',
                        'shipping_address'
                    ];

                data['order[shipping_method]'] = method;

                if (method === STORE_PICKUP_METHOD) {
                    data = this.serializeData(this.shippingAddressContainer).toObject();
                    data['order[shipping_method]'] = method;
                    data['shipping_as_billing'] = 0;
                    data['save_in_address_book'] = 0;
                    this.shippingAsBilling = 0;
                    this.saveInAddressBook = 0;
                }
                this.storePickupData = data;
                this.loadArea(areas, true, data).then(
                    function () {
                        setStorePickupMethod(method === STORE_PICKUP_METHOD);
                    }
                );
            };

            /**
             * Replace shipping method area.
             * Restore store pickup shipping method if it was already selected.
             */
            window.AdminOrder.prototype.resetShippingMethod = function () {
                var storePickupCheckbox = jQuery(IN_STORE_PICKUP_CHECKBOX_SELECTOR);

                if (!this.isOnlyVirtualProduct) {
                    /* eslint-disable no-undef */
                    $(this.getAreaId('shipping_method')).update(this.shippingTemplate);

                    if (isStorePickupSelected()) {
                        window.order.setShippingMethod(storePickupCheckbox.val());
                    }
                }
            };

            /**
             * loadArea method override
             *
             * @param {String} method
             */
            window.AdminOrder.prototype.loadArea = function (area, indicator, params) {
                var deferred = new jQuery.Deferred();
                var url = this.loadBaseUrl;
                if (area) {
                    area = this.prepareArea(area);
                    url += 'block/' + area;
                }
                if (indicator === true) indicator = 'html-body';
                params = this.prepareParams(params);
                if (this.storePickupData.length !== 0) {
                    if (params.hasOwnProperty('order[shipping_address][firstname]')) {
                        delete params['order[shipping_address][firstname]'];
                    }
                    if (params.hasOwnProperty('order[shipping_address][lastname]')) {
                        delete params['order[shipping_address][lastname]'];
                    }
                    if (params.hasOwnProperty('order[shipping_address][company]')) {
                        delete params['order[shipping_address][company]'];
                    }
                    if (this.storePickupData.hasOwnProperty('order[shipping_method]')) {
                        params['order[shipping_method]'] = this.storePickupData['order[shipping_method]'];
                    }
                    if (this.storePickupData.hasOwnProperty('shipping_as_billing')) {
                        params['shipping_as_billing'] = this.storePickupData['shipping_as_billing'];
                    }
                    if (this.storePickupData.hasOwnProperty('save_in_address_book')) {
                        params['save_in_address_book'] = this.storePickupData['save_in_address_book'];
                    }
                    if (this.storePickupData.hasOwnProperty('order[shipping_address][suffix]')) {
                        params['order[shipping_address][suffix]'] = this.storePickupData['order[shipping_address][suffix]'];
                    }
                    if (this.storePickupData.hasOwnProperty('order[shipping_address][street][0]')) {
                        params['order[shipping_address][street][0]'] = this.storePickupData['order[shipping_address][street][0]'];
                    }
                    if (this.storePickupData.hasOwnProperty('order[shipping_address][country_id]')) {
                        params['order[shipping_address][country_id]'] = this.storePickupData['order[shipping_address][country_id]'];
                    }
                    if (this.storePickupData.hasOwnProperty('order[shipping_address][region]')) {
                        params['order[shipping_address][region]'] = this.storePickupData['order[shipping_address][region]'];
                    }
                    if (this.storePickupData.hasOwnProperty('order[shipping_address][region_id]')) {
                        params['order[shipping_address][region_id]'] = this.storePickupData['order[shipping_address][region_id]'];
                    }
                    if (this.storePickupData.hasOwnProperty('order[shipping_address][city]')) {
                        params['order[shipping_address][city]'] = this.storePickupData['order[shipping_address][city]'];
                    }
                }
                params.json = true;
                if (!this.loadingAreas) this.loadingAreas = [];
                if (indicator) {
                    this.loadingAreas = area;
                    new Ajax.Request(url, {
                        parameters: params,
                        loaderArea: indicator,
                        onSuccess: function (transport) {
                            var response = transport.responseText.evalJSON();
                            this.loadAreaResponseHandler(response);
                            deferred.resolve();
                        }.bind(this)
                    });
                } else {
                    new Ajax.Request(url, {
                        parameters: params,
                        loaderArea: indicator,
                        onSuccess: function (transport) {
                            deferred.resolve();
                        }
                    });
                }
                if (typeof productConfigure != 'undefined' && area instanceof Array && area.indexOf('items') != -1) {
                    productConfigure.clean('quote_items');
                }
                return deferred.promise();
            };

            window.AdminOrder.prototype.submit = function () {
                var self = this;
                var $editForm = jQuery('#edit_form'),
                    beforeSubmitOrderEvent;
                beforeSubmitOrderEvent = jQuery.Event('beforeSubmitOrder');
                $editForm.trigger(beforeSubmitOrderEvent);
                if (beforeSubmitOrderEvent.result !== false) {
                    if ($editForm.valid()) {
                        if (jQuery('#modification-reason-popup-modal').length) {
                            jQuery('body').trigger('processStart');
                            let transactionModificationReasonTypeUrl = '/rest/V1/canpay/get-modification-reason-type',
                                requestData = JSON.stringify({
                                    'quote_id': window.order.quoteId
                                });
                            jQuery.ajax({
                                type:'POST',
                                url:transactionModificationReasonTypeUrl,
                                async: false,
                                dataType: 'json',
                                contentType: "application/json",
                                data: requestData,
                                beforeSend: function(xhr){}
                            }).done (function (result) {
                                jQuery('body').trigger('processStop');
                                result = JSON.parse(result);
                                if (result['success']) {
                                    jQuery('#modification-reason-popup-modal').modal('openModal');
                                    jQuery('input[type="radio"][name="modification_reason_type"]').each(function() {
                                        if (jQuery(this).val() == result['modification_reason_type']) {
                                            jQuery(this).prop('checked', true);
                                            jQuery('input[type="radio"][name="modification_reason_type"]').trigger('change');
                                        }
                                    });
                                }
                            });
                        } else {
                            $editForm.trigger('processStart');
                            if (jQuery('#modification-reason-popup-modal .error-message').length == 0) {
                                $editForm.trigger('submitOrder');
                            }
                        }
                    }
                }
            };
        };
    }
);
