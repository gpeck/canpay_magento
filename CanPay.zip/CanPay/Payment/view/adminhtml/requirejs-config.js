var config = {
    map: {
        '*': {
            modificationReasonModal: 'CanPay_Payment/js/modification-reason-modal',
            canpaypaymentDashboard: 'CanPay_Payment/js/canpaypayment-dashboard',
            'Magento_InventoryInStorePickupSalesAdminUi/order/create/scripts-mixin': 'CanPay_Payment/js/order/create/scripts-mixin',
            'Magento_Ui/js/grid/columns/actions': 'CanPay_Payment/js/actions',
            uiGridColumnsActions: 'Magento_Ui/js/grid/columns/actions'
        }
    }
};
