var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/billing-address': {
                'CanPay_Payment/js/view/billing-address': true
            }
        }
    }
};
