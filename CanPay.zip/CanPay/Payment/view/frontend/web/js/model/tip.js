define([
    'ko',
    'domReady!'
], function (ko) {
    'use strict';

    var tipAmount = ko.observable(null),
        isApplied = ko.observable(null);

    return {
        tipAmount: tipAmount,
        isApplied: isApplied,

        /**
         * @return {*}
         */
        getTipAmount: function () {
            return tipAmount;
        },

        /**
         * @return {Boolean}
         */
        getIsApplied: function () {
            return isApplied;
        },

        /**
         * @param {*} tipAmountValue
         */
        setTipAmount: function (tipAmountValue) {
            tipAmount(tipAmountValue);
        },

        /**
         * @param {Boolean} isAppliedValue
         */
        setIsApplied: function (isAppliedValue) {
            isApplied(isAppliedValue);
        }
    };
});
