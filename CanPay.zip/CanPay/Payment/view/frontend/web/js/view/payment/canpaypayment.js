define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'canpaypayment',
                component: 'CanPay_Payment/js/view/payment/method-renderer/canpaypayment'
            }
        );
        return Component.extend({});
    }
);