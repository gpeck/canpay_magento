define([
    'Magento_Checkout/js/model/quote'
], function (quote) {
    'use strict';

    var storePickupShippingInformation = {
        defaults: {
            template: 'CanPay_Payment/billing-address',
        },

        /**
         *
         * @returns {boolean}
         */
        isCanPayment:  function () {
            var paymentMethod = quote.paymentMethod(),
                isCanPayment = false;
            if (paymentMethod !== null) {
                isCanPayment = paymentMethod['method'] === 'canpaypayment';
            }
            return isCanPayment;
        },

        /**
         * Get is store pickup delivery method selected.
         *
         * @returns {Boolean}
         */
        isStorePickup: function () {
            var shippingMethod = quote.shippingMethod(),
                isStorePickup = false;
            if (shippingMethod !== null) {
                isStorePickup = shippingMethod['carrier_code'] === 'instore' &&
                    shippingMethod['method_code'] === 'pickup';
            }
            return isStorePickup;
        },

        /**
         *
         * @returns {*}
         */
        isVirtual:  function () {
            return quote.isVirtual();
        },
    };

    return function (shippingInformation) {
        return shippingInformation.extend(storePickupShippingInformation);
    };
});
