define(
    [
        'jquery',
        'Magento_Checkout/js/view/summary/abstract-total',
        'Magento_Checkout/js/model/quote',
        'Magento_Checkout/js/model/totals',
        'Magento_Catalog/js/price-utils'
    ],
    function ($, Component, quote, totals, priceUtils) {
        "use strict";
        return Component.extend({
            defaults: {
                template: 'CanPay_Payment/checkout/summary/tip-amount'
            },
            totals: quote.getTotals(),
            isDisplayedTipTotal: function () {
                if (window.checkoutConfig.isCanPaymentEnable == 0) {
                    return false;
                }
                return true;
            },
            getTipAmountTotal: function () {
                var tipAmount = totals.getSegment('tip_amount').value;
                return this.getFormattedPrice(tipAmount);
            }
        });
    }
);
