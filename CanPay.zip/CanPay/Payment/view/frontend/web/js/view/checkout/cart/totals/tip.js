define(
    [
        'CanPay_Payment/js/view/checkout/summary/tip-amount'
    ],
    function (Component) {
        'use strict';
        return Component.extend({
            /**
             * @override
             */
            isDisplayed: function () {
                return true;
            }
        });
    }
);
