define([
	'jquery',
    'Magento_Checkout/js/view/payment/default',
    'Magento_Customer/js/customer-data',
    'Magento_Customer/js/model/customer',
    'Magento_Checkout/js/model/quote',
    'Magento_Ui/js/model/messageList',
    'Magento_Checkout/js/model/payment/additional-validators',
    'Magento_Checkout/js/action/redirect-on-success',
    'Magento_Checkout/js/action/select-billing-address',
    'Magento_Checkout/js/model/totals'
], function ($, Component, customerData, customer, quote, messageList, additionalValidators, redirectOnSuccessAction, selectBillingAddress, totals) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'CanPay_Payment/payment/canpaypayment',
            canpaypaymentSignature: '',
            canpaypaymentResponse: ''
        },

        /**
         * @returns {String}
         */
        getCode: function () {
            return 'canpaypayment';
        },

        /**
         * @returns {Object}
         */
        getData: function() {
            return {
                'method': this.getCode(),
                'additional_data': {
                    'canpaypayment_signature': this.canpaypaymentSignature,
                    'canpaypayment_response': this.canpaypaymentResponse
                }
            };
        },

        /**
         * Adds error message
         *
         * @param {String} message
         */
        addError: function (message) {
            messageList.addErrorMessage({
                message: message
            });
        },

        /**
         * @override
         */
        initCanPay: function () {
        	var self = this;
        	let url = BASE_URL + 'rest/V1/canpay/get-canpay-config';
        	$.ajax({
        		method: 'GET',
                url: url,
                async: false,
            }).done (function (result) {
            	result = JSON.parse(result);
            	let intentId = result['intent_id'] ? result['intent_id'] : null,
            		authId = result['auth_id'] ? result['auth_id'] : null,
            	    message = result['message'] ? result['message'] : '',
            	    quoteTotals = quote.totals(),
                    tip = totals.getSegment('tip_amount').value,
            	    grandTotal = (quoteTotals ? quoteTotals : quote)['grand_total'] - tip;
	            if (result['success']) {
	            	var config = {
        				'intent_id': intentId,
        				'amount': grandTotal,
        				'tip_amount': tip,
        				'original_merchant': '',
        				'is_guest': !customer.isLoggedIn(),
        				'passthrough': {},
        				'auth_id': authId,
        				'login_callback': function(response) {},
        				'link_callback': function(response) {
        					if (response.code == 200) {
        						self.saveAuthId(response.data.auth_id, self);
        					}
        				},
        				'processed_callback': function(response) {
        					if (response.data.response && response.data.signature) {
        						self.checkSignature(response.data.response, response.data.signature, self);
        					}
        				}
        			};
        			canpay.init(config);
	            } else {
	                self.addError(message);
	                return reject(new Error(error));
	            }
            });
        },

        /**
         * @override
         */
        saveAuthId: function (authId, self) {
        	let url = BASE_URL + 'rest/V1/canpay/save-auth-id',
				requestData = JSON.stringify({
					'auth_id': authId
		        });
			$.ajax({
				method: 'POST',
	            url: url,
	            async: false,
	            dataType: 'json',
	            contentType: "application/json",
	            data: requestData
	        }).done (function (result) {});
        },

        /**
         * @override
         */
        checkSignature: function (response, signature, self) {
        	let url = BASE_URL + 'rest/V1/canpay/check-signature',
				requestData;
			requestData = JSON.stringify({
				'response': response,
				'signature': signature
	        });

			$.ajax({
				method: 'POST',
	            url: url,
	            async: false,
	            dataType: 'json',
	            contentType: "application/json",
	            data: requestData
	        }).done (function (result) {
	        	result = JSON.parse(result);
	        	let message = result['message'] ? result['message'] : '';
	            if(result['success']) {
	            	self.canpaypaymentSignature = signature;
	            	self.canpaypaymentResponse = response;
	            	return self.placeOrder();
	            } else {
	                self.addError(message);
	                return reject(new Error(error));
	            }
	        });
        },

        /**
         * Place order.
         */
        placeOrder: function (data, event) {
            var self = this;

            if (event) {
                event.preventDefault();
            }
            if (quote.billingAddress() == null) {
            	this.applyBillingAddress();
            }

            if (this.validate() &&
                additionalValidators.validate() &&
                this.isPlaceOrderActionAllowed() === true
            ) {
                this.isPlaceOrderActionAllowed(false);

                this.getPlaceOrderDeferredObject()
                    .done(
                        function () {
                            self.afterPlaceOrder();

                            if (self.redirectAfterPlaceOrder) {
                                redirectOnSuccessAction.execute();
                            }
                        }
                    ).always(
                        function () {
                            self.isPlaceOrderActionAllowed(true);
                        }
                    );

                return true;
            }

            return false;
        },

        applyBillingAddress: function () {
            var shippingAddress;

            shippingAddress = quote.shippingAddress();
            if (shippingAddress) {
                //set billing address same as shipping by default if it is not empty
                selectBillingAddress(quote.shippingAddress());
            }
        }
    });
});
