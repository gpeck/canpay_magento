define([
    'jquery',
    'ko',
    'uiComponent',
    'Magento_Checkout/js/model/quote',
    'CanPay_Payment/js/action/set-tip-amount',
    'CanPay_Payment/js/action/cancel-tip',
    'CanPay_Payment/js/model/tip',
    'Magento_Checkout/js/model/totals'
], function ($, ko, Component, quote, setTipAmountAction, cancelTipAction, tip, totals) {
    'use strict';

    var tipAmount = tip.getTipAmount(),
        isApplied = tip.getIsApplied();
    tipAmount(totals.getSegment('tip_amount').value);
    isApplied(tipAmount() != null);

    return Component.extend({
        defaults: {
            template: 'CanPay_Payment/payment/tip'
        },
        tipAmount: tipAmount,

        /**
         * Applied flag
         */
        isApplied: isApplied,

        /**
         * Tip Amount application procedure
         */
        apply: function () {
            if (this.validate()) {
                setTipAmountAction(tipAmount(), isApplied);
            }
        },

        /**
         * Cancel using tip
         */
        cancel: function () {
            if (this.validate()) {
                tipAmount(0);
                cancelTipAction(isApplied);
            }
        },

        /**
         * tip form validation
         *
         * @returns {Boolean}
         */
        validate: function () {
            var form = '#tip-form';

            return $(form).validation() && $(form).validation('isValid');
        }
    });
});
