define([
    'ko',
    'jquery',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/resource-url-manager',
    'Magento_Checkout/js/model/error-processor',
    'CanPay_Payment/js/model/payment/tip-messages',
    'mage/storage',
    'mage/translate',
    'Magento_Checkout/js/action/get-payment-information',
    'Magento_Checkout/js/model/totals',
    'Magento_Checkout/js/model/full-screen-loader',
    'Magento_Checkout/js/action/recollect-shipping-rates'
], function (ko, $, quote, urlManager, errorProcessor, messageContainer, storage, $t, getPaymentInformationAction,
    totals, fullScreenLoader, recollectShippingRates
) {
    'use strict';

    var action;

    /**
     * Apply provided tip.
     *
     * @param {String} tipAmount
     * @param {Boolean}isApplied
     * @returns {Deferred}
     */
    action = function (tipAmount, isApplied) {
        let applyTipUrl = '/rest/V1/canpay/apply-tip',
            message = $t('Your tip was successfully applied.'),
            requestData = JSON.stringify({
                'tip_amount': tipAmount,
                'quote_id': quote.getQuoteId()
            });
        fullScreenLoader.startLoader();
        $.ajax({
            method: 'POST',
            url: applyTipUrl,
            async: false,
            dataType: 'json',
            contentType: "application/json",
            data: requestData,
            beforeSend: function(xhr){}
        }).done (function (result) {
            let deferred;
            result = JSON.parse(result);
            if (result['success']) {
                deferred = $.Deferred();
                isApplied(true);
                totals.isLoading(true);
                recollectShippingRates();
                getPaymentInformationAction(deferred);
                $.when(deferred).done(function () {
                    fullScreenLoader.stopLoader();
                    totals.isLoading(false);
                });
                messageContainer.addSuccessMessage({
                    'message': message
                });
            }
        });
    };
    return action;
});
