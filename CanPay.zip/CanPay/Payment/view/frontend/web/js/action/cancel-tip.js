define([
    'jquery',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/resource-url-manager',
    'Magento_Checkout/js/model/error-processor',
    'CanPay_Payment/js/model/payment/tip-messages',
    'mage/storage',
    'Magento_Checkout/js/action/get-payment-information',
    'Magento_Checkout/js/model/totals',
    'mage/translate',
    'Magento_Checkout/js/model/full-screen-loader',
    'Magento_Checkout/js/action/recollect-shipping-rates'
], function ($, quote, urlManager, errorProcessor, messageContainer, storage, getPaymentInformationAction, totals, $t,
  fullScreenLoader, recollectShippingRates
) {
    'use strict';

    var successCallbacks = [],
        action,
        callSuccessCallbacks;

    /**
     * Execute callbacks when a tip is successfully canceled.
     */
    callSuccessCallbacks = function () {
        successCallbacks.forEach(function (callback) {
            callback();
        });
    };

    /**
     * Cancel applied tip.
     *
     * @param {Boolean} isApplied
     * @returns {Deferred}
     */
    action =  function (isApplied) {
        let cancelTipUrl = '/rest/V1/canpay/cancel-tip',
            message = $t('Your tip was successfully removed.'),
            requestData = JSON.stringify({
                'quote_id': quote.getQuoteId()
            });
        fullScreenLoader.startLoader();
        $.ajax({
            method: 'POST',
            url: cancelTipUrl,
            async: false,
            dataType: 'json',
            contentType: "application/json",
            data: requestData,
            beforeSend: function(xhr){}
        }).done (function (result) {
            let deferred;
            result = JSON.parse(result);
            if (result['success']) {
                recollectShippingRates();
                getPaymentInformationAction(deferred);
                $.when(deferred).done(function () {
                    isApplied(false);
                    totals.isLoading(false);
                    fullScreenLoader.stopLoader();
                });
                messageContainer.addSuccessMessage({
                    'message': message
                });
            }
        });
    };
    return action;
});
