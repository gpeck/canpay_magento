<?php

namespace CanPay\Payment\Setup\Patch\Data;

use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Framework\App\Config\ConfigResource\ConfigInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

class SetConfigData implements DataPatchInterface
{
    
    const XML_PATH_WEB_SECURE_BASE_URL = 'web/secure/base_url';
    
    /**
     *
     * @var ConfigInterface
     */
    protected $configInterface;
    
    /**
     * 
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;
    
    /**
     * 
     * @param ConfigInterface $configInterface
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        ConfigInterface $configInterface,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->configInterface = $configInterface;
        $this->scopeConfig = $scopeConfig;
    }
    
    /**
     * {@inheritdoc}
     */
    public function apply()
    {
        $this->configInterface->saveConfig('payment/canpaypayment/callback_url', $this->getWebSecureBaseUrl() . 'rest/V1/canpay/callback', ScopeConfigInterface::SCOPE_TYPE_DEFAULT, 0);
    }
    
    /**
     *
     * @return string
     */
    public function getWebSecureBaseUrl($scopeType = ScopeConfigInterface::SCOPE_TYPE_DEFAULT, $scopeCode = null)
    {
        return $this->scopeConfig->getValue(self::XML_PATH_WEB_SECURE_BASE_URL, $scopeType, $scopeCode);
    }
    
    /**
     * {@inheritdoc}
     */
    public static function getDependencies()
    {
        return [];
    }
    
    /**
     * {@inheritdoc}
     */
    public function getAliases()
    {
        return [];
    }
}