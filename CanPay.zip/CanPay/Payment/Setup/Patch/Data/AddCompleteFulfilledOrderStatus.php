<?php

namespace CanPay\Payment\Setup\Patch\Data;

use Exception;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Sales\Model\Order\Status;
use Magento\Sales\Model\Order\StatusFactory;
use Magento\Sales\Model\ResourceModel\Order\Status as StatusResource;
use Magento\Sales\Model\ResourceModel\Order\StatusFactory as StatusResourceFactory;

class AddCompleteFulfilledOrderStatus implements DataPatchInterface
{
    const ORDER_STATUS_COMPLETE_FULFILLED_CODE = 'complete_fulfilled';
    const ORDER_STATUS_COMPLETE_FULFILLED_LABEL = 'Complete Fulfilled';
    const ORDER_STATE_COMPLETE_FULFILLED_CODE = 'complete_fulfilled';

    /**
     *
     * @var StatusFactory
     */
    protected $statusFactory;

    /**
     *
     * @var StatusResourceFactory
     */
    protected $statusResourceFactory;

    /**
     * @param StatusFactory $statusFactory
     * @param StatusResourceFactory $statusResourceFactory
     */
    public function __construct(
        StatusFactory $statusFactory,
        StatusResourceFactory $statusResourceFactory
    ) {
        $this->statusFactory = $statusFactory;
        $this->statusResourceFactory = $statusResourceFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function apply()
    {
        $this->addNewOrderStatus();
    }

    /**
     * {@inheritdoc}
     */
    public static function getDependencies()
    {
        return [];
    }

    /**
     * {@inheritdoc}
     */
    public function getAliases()
    {
        return [];
    }

    /**
     *
     * @return void
     *
     * @throws Exception
     */
    protected function addNewOrderStatus()
    {
        /** @var StatusResource $statusResource */
        $statusResource = $this->statusResourceFactory->create();
        /** @var Status $status */
        $status = $this->statusFactory->create();
        $status->setData([
            'status' => self::ORDER_STATUS_COMPLETE_FULFILLED_CODE,
            'label' => self::ORDER_STATUS_COMPLETE_FULFILLED_LABEL,
        ]);
        try {
            $statusResource->save($status);
        } catch (AlreadyExistsException $exception) {
            return;
        }
        $status->assignState(self::ORDER_STATE_COMPLETE_FULFILLED_CODE, false, true);
    }
}
