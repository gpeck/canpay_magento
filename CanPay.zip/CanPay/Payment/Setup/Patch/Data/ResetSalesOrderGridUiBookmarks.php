<?php

namespace CanPay\Payment\Setup\Patch\Data;

use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Ui\Api\Data\BookmarkInterfaceFactory;
use Magento\Ui\Model\ResourceModel\BookmarkRepository;

class ResetSalesOrderGridUiBookmarks implements DataPatchInterface
{

    /**
     *
     * @var BookmarkInterfaceFactory
     */
    protected $bookmarkFactory;

    /**
     *
     * @var BookmarkRepository
     */
    protected $bookmarkRepository;

    /**
     * @param BookmarkInterfaceFactory $bookmarkFactory
     * @param BookmarkRepository $bookmarkRepository
     */
    public function __construct(
        BookmarkInterfaceFactory $bookmarkFactory,
        BookmarkRepository $bookmarkRepository
    ) {
        $this->bookmarkFactory = $bookmarkFactory;
        $this->bookmarkRepository = $bookmarkRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function apply()
    {
        try {
            $collection = $this->bookmarkFactory->create()->getCollection();
            $collection->addFieldToFilter('namespace', ['eq' => 'sales_order_grid']);

            if (!empty($collection->getItems())) {

                foreach ($collection->getItems() as $bookmark) {
                    $this->bookmarkRepository->deleteById($bookmark->getBookmarkId());
                }

            }
        } catch (\Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: Cannot reset bookmarks. Message: ' . $e->getMessage());
        }
    }

    /**
     * {@inheritdoc}
     */
    public static function getDependencies()
    {
        return [];
    }

    /**
     * {@inheritdoc}
     */
    public function getAliases()
    {
        return [];
    }
}
