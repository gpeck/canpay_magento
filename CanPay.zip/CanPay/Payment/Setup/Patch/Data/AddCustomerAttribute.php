<?php

namespace CanPay\Payment\Setup\Patch\Data;

use Magento\Customer\Model\Customer;
use Magento\Eav\Model\Config;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;

class AddCustomerAttribute implements DataPatchInterface
{
    /**
     * 
     * @var CustomerSetupFactory
     */
    private $customerSetupFactory;

    /**
     * 
     * @var ModuleDataSetupInterface
     */
    private $setup;

    /**
     * 
     * @var Config
     */
    private $eavConfig;

    /**
     * 
     * @param ModuleDataSetupInterface $setup
     * @param Config $eavConfig
     * @param CustomerSetupFactory $customerSetupFactory
     */
    public function __construct(
        ModuleDataSetupInterface $setup,
        Config $eavConfig,
        CustomerSetupFactory $customerSetupFactory
    )
    {
        $this->customerSetupFactory = $customerSetupFactory;
        $this->setup = $setup;
        $this->eavConfig = $eavConfig;
    }

    public function apply()
    {
        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->setup]);
        $customerEntity = $customerSetup->getEavConfig()->getEntityType(Customer::ENTITY);
        $attributeSetId = $customerSetup->getDefaultAttributeSetId($customerEntity->getEntityTypeId());
        $attributeGroup = $customerSetup->getDefaultAttributeGroupId($customerEntity->getEntityTypeId(), $attributeSetId);
        $customerSetup->addAttribute(Customer::ENTITY, 'canpaypayment_auth_id', [
            'label' => 'CanPay Payment auth_id',
            'required' => 0,
            'position' => 100,
            'system' => 0,
            'user_defined' => 1,
            'is_used_in_grid' => 0,
            'is_visible_in_grid' => 0,
            'is_filterable_in_grid' => 0,
            'is_searchable_in_grid' => 0,
            'visible' => 0
        ]);
        $newAttribute = $this->eavConfig->getAttribute(Customer::ENTITY, 'canpaypayment_auth_id');
        $newAttribute->addData([
            'used_in_forms' => ['adminhtml_checkout','adminhtml_customer','customer_account_edit','customer_account_create'],
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroup
        ]);
        $newAttribute->save();
    }

    public static function getDependencies()
    {
        return [];
    }

    public function getAliases()
    {
        return [];
    }
}