<?php

namespace CanPay\Payment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use CanPay\Payment\Helper\Data as Helper;
use CanPay\Payment\Helper\Api as HelperApi;

class UpdateTransactionDetails implements ObserverInterface {

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var HelperApi
     */
    protected $helperApi;

    /**
     * @param LoggerInterface $logger
     * @param Helper $helper
     * @param HelperApi $helperApi
     */
    public function __construct(
        LoggerInterface $logger,
        Helper $helper,
        HelperApi $helperApi
    ) {
        $this->logger = $logger;
        $this->helper = $helper;
        $this->helperApi = $helperApi;
    }

    /**
     * @param EventObserver $observer
     * @return void
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute(EventObserver $observer) {
        if ($this->helper->getEnable()) {
            try {
                $controllerAction = $observer->getControllerAction();
                $transactionId = $controllerAction->getRequest()->getParam('txn_id');
                $transaction = $this->helper->getTransactionById($transactionId);
                if ($transaction) {
                    $order = $this->helper->getOrderById($transaction->getOrderId());
                    if ($order && $this->helper->isCanPayPayment($order)) {
                        if ($intentId = $order->getCanpaypaymentIntentId()) {
                            if ($transactionDetails = $this->helperApi->getTransactionDetails($intentId)) {
                                if ($transactionDetails['transaction_number']) {
                                    $transaction->setAdditionalInformation(\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS, $transactionDetails);
                                    $order->setCanpaypaymentStatus($transactionDetails['status']);
                                }
                            }
                            $transaction->save();
                            $order->save();
                        }
                    }
                }
            } catch (Exception $e) {
                $this->logger->error('CanPay_Payment ERROR: Transactions Status was not updated. Message: ' . $e->getMessage());
            }
        }
    }
}
