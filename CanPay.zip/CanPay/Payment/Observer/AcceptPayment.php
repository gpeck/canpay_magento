<?php

namespace CanPay\Payment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Message\ManagerInterface as MessageManagerInterface;
use Magento\Sales\Model\Order;
use Psr\Log\LoggerInterface;
use CanPay\Payment\Helper\Data as Helper;
use CanPay\Payment\Helper\Api as HelperApi;

class AcceptPayment implements ObserverInterface {

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var HelperApi
     */
    protected $helperApi;

    /**
     *
     * @var MessageManagerInterface
     */
    protected $messageManager;

    /**
     * @param LoggerInterface $logger
     * @param Helper $helper
     * @param HelperApi $helperApi
     * @param MessageManagerInterface $messageManager
     */
    public function __construct(
        LoggerInterface $logger,
        Helper $helper,
        HelperApi $helperApi,
        MessageManagerInterface $messageManager
    ) {
        $this->logger = $logger;
        $this->helper = $helper;
        $this->helperApi = $helperApi;
        $this->messageManager = $messageManager;
    }

    /**
     * @param EventObserver $observer
     * @return void
     */
    public function execute(EventObserver $observer) {
        if ($this->helper->getEnable()) {
            $order = $observer->getEvent()->getOrder();
            try {
                if ($this->helper->isCanPayPayment($order)) {
                    if ($intentId = $order->getCanpaypaymentIntentId()) {
                        if ($this->helper->isOrderReadyForPickup($order->getId())) {
                            if ($order->getStatus() == Order::STATE_COMPLETE || $order->getStatus() == \CanPay\Payment\Setup\Patch\Data\AddCompleteFulfilledOrderStatus::ORDER_STATE_COMPLETE_FULFILLED_CODE) {
                                $resultAcceptPayment = $this->helperApi->acceptPayment($intentId);
                                if ($resultAcceptPayment) {
                                    if ($resultAcceptPayment['code'] == 200) {
                                        if (isset($resultAcceptPayment['message'])) {
                                            $this->messageManager->addSuccess(__('CanPay Payment accepted and status updated'));
                                        }
                                    } else {
                                        if (isset($resultAcceptPayment['message'])) {
                                            $this->messageManager->addError(__('CanPay Payment Accept Payment: ' . $resultAcceptPayment['message']));
                                            $this->logger->error('CanPay_Payment ERROR Accept Payment: ' . $resultAcceptPayment['message']);
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        $this->logger->error('CanPay_Payment ERROR: Accept Payment. intent_id was not set for order with id ' . $order->getId());
                    }
                }
            } catch (Exception $e) {
                $this->logger->error('CanPay_Payment ERROR: Accept Payment. Message: ' . $e->getMessage());
            }
        }
    }
}
