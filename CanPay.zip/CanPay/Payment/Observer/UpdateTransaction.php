<?php

namespace CanPay\Payment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Message\ManagerInterface as MessageManagerInterface;
use Psr\Log\LoggerInterface;
use CanPay\Payment\Helper\Data as Helper;
use CanPay\Payment\Helper\Api as HelperApi;
use Magento\Sales\Api\OrderStatusHistoryRepositoryInterface;

class UpdateTransaction implements ObserverInterface {

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var HelperApi
     */
    protected $helperApi;

    /**
     *
     * @var MessageManagerInterface
     */
    protected $messageManager;

    /**
     *
     * @var OrderStatusHistoryRepositoryInterface
     */
    private $orderStatusRepository;

    /**
     * @param LoggerInterface $logger
     * @param Helper $helper
     * @param HelperApi $helperApi
     * @param MessageManagerInterface $messageManager
     * @param OrderStatusHistoryRepositoryInterface $orderStatusRepository
     */
    public function __construct(
        LoggerInterface $logger,
        Helper $helper,
        HelperApi $helperApi,
        MessageManagerInterface $messageManager,
        OrderStatusHistoryRepositoryInterface $orderStatusRepository
    ) {
        $this->logger = $logger;
        $this->helper = $helper;
        $this->helperApi = $helperApi;
        $this->messageManager = $messageManager;
        $this->orderStatusRepository = $orderStatusRepository;
    }

    /**
     * @param EventObserver $observer
     * @return void
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function execute(EventObserver $observer) {
        if ($this->helper->getEnable()) {
            try {
                $payment = $observer->getEvent()->getPayment();
                $order = $payment->getOrder();
                $oldOrder = $this->helper->getCurrentOrder();
                if ($this->helper->isCanPayPayment($order)) {
                    if (count($this->helper->getTransactionsByOrderId($order->getId())) == 0) {
                        if ($order->getId() && $oldOrder && $order->getId() !== $oldOrder->getId()) {
                            if ($intentId = $order->getCanpaypaymentIntentId()) {
                                $result = $this->helperApi->transactionUpdate($intentId, $order->getGrandTotal() - $order->getTipAmount(), $oldOrder->getCanpaypaymentModificationReasonId(), $oldOrder->getCanpaypaymentModificationReasonComment());
                                if ($result) {
                                    if ($result['code'] == 200 || $result['code'] == 202) {
                                        if (isset($result['message'])) {
                                            $this->messageManager->addSuccess(__('CanPay Payment transactionupdate: ' . $result['message']));
                                        }
                                    } else {
                                        if (isset($result['message'])) {
                                            $this->messageManager->addError(__('CanPay Payment transactionupdate: ' . $result['message']));
                                            $this->logger->error('CanPay_Payment ERROR transactionupdate: ' . $result['message']);
                                        }
                                    }
                                }

                                $modificationHistoryResult = $this->helperApi->modificationHistory($intentId);
                                if ($modificationHistoryResult) {
                                    if ($modificationHistoryResult['code'] == 200) {
                                        if (isset($modificationHistoryResult['data']) && count($modificationHistoryResult['data']) > 0) {
                                            $commentString = 'Transaction modification history:<br>';
                                            foreach ($modificationHistoryResult['data'] as $modificationHistory) {
                                                $reason = $modificationHistory['reason'] ? $modificationHistory['reason'] : $modificationHistory['additional_reason'];
                                                $commentString .= '<b>Status:</b> ' . $modificationHistory['status']
                                                    . ', <b>reason:</b> ' . $reason
                                                    . ', <b>amount:</b> ' . $modificationHistory['amount']
                                                    . ', <b>local transaction time:</b> ' . $modificationHistory['local_transaction_time'] . '<br>';
                                            }
                                            $comment = $order->addStatusHistoryComment(
                                                $commentString
                                            );
                                            $this->messageManager->addSuccess(__('CanPay Payment modificationhistory: ' . $modificationHistoryResult['message']));
                                        }
                                    } else {
                                        if (isset($modificationHistoryResult['message'])) {
                                            $this->messageManager->addError(__('CanPay Payment modificationhistory: ' . $modificationHistoryResult['message']));
                                            $this->logger->error('CanPay_Payment ERROR modificationhistory: ' . $modificationHistoryResult['message']);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                $this->logger->error('CanPay_Payment ERROR: Transaction was not updated. Message: ' . $e->getMessage());
            }
        }
    }
}
