<?php

namespace CanPay\Payment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use CanPay\Payment\Helper\Data as Helper;
use CanPay\Payment\Helper\Api as HelperApi;
use Magento\Sales\Api\OrderStatusHistoryRepositoryInterface;

class UpdateModificationHistory implements ObserverInterface {

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var HelperApi
     */
    protected $helperApi;

    /**
     *
     * @var OrderStatusHistoryRepositoryInterface
     */
    private $orderStatusHistoryRepository;

    /**
     * @param LoggerInterface $logger
     * @param Helper $helper
     * @param HelperApi $helperApi
     * @param OrderStatusHistoryRepositoryInterface $orderStatusHistoryRepository
     */
    public function __construct(
        LoggerInterface $logger,
        Helper $helper,
        HelperApi $helperApi,
        OrderStatusHistoryRepositoryInterface $orderStatusHistoryRepository
    ) {
        $this->logger = $logger;
        $this->helper = $helper;
        $this->helperApi = $helperApi;
        $this->orderStatusHistoryRepository = $orderStatusHistoryRepository;
    }

    /**
     * @param EventObserver $observer
     * @return void
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function execute(EventObserver $observer) {
        if ($this->helper->getEnable()) {
            try {
                $controllerAction = $observer->getControllerAction();
                $orderId = $controllerAction->getRequest()->getParam('order_id');
                $order = $this->helper->getOrderById($orderId);
                if ($order && $this->helper->isCanPayPayment($order)) {
                    $quote = $this->helper->getQuoteById($order->getQuoteId());
                    $transactions = $this->helper->getTransactionsByOrderId($orderId);
                    if (count($transactions) > 0) {
                        if ($intentId = $order->getCanpaypaymentIntentId()) {
                            $modificationHistoryResult = $this->helperApi->modificationHistory($intentId);
                            if ($modificationHistoryResult && $modificationHistoryResult['code'] == 200) {
                                if (isset($modificationHistoryResult['data']) && count($modificationHistoryResult['data']) > 0) {
                                    $histories = $order->getStatusHistories();
                                    $historyComments = [];
                                    foreach ($histories as $history) {
                                        array_push($historyComments, $history->getComment());
                                    }
                                    $commentString = 'Transaction modification history:<br>';
                                    foreach ($modificationHistoryResult['data'] as $modificationHistory) {
                                        $reason = $modificationHistory['reason'] ? $modificationHistory['reason'] : $modificationHistory['additional_reason'];
                                        $commentString .= '<b>Status:</b> ' . $modificationHistory['status']
                                            . ', <b>reason:</b> ' . $reason
                                            . ', <b>amount:</b> ' . $modificationHistory['amount']
                                            . ', <b>local transaction time:</b> ' . $modificationHistory['local_transaction_time'] . '<br>';
                                    }
                                    $comment = $order->addStatusHistoryComment(
                                        $commentString
                                    );
                                    if (!in_array($comment->getComment(), $historyComments)) {
                                        $this->orderStatusHistoryRepository->save($comment);

                                        foreach ($transactions as $transaction) {
                                            $transaction->setTxnStatus($modificationHistoryResult['data'][0]['status']);
                                            if ($transactionDetails = $this->helperApi->getTransactionDetails($intentId)) {
                                                if ($transactionDetails['transaction_number']) {
                                                    $transaction->setAdditionalInformation(\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS, $transactionDetails);

                                                    $order->setGrandTotal($order->getGrandTotal() - $order->getTipAmount() + $transactionDetails['tip_amount']);
                                                    $order->setBaseGrandTotal($order->getBaseGrandTotal() - $order->getTipAmount() + $transactionDetails['tip_amount']);
                                                    $order->setTipAmount($transactionDetails['tip_amount']);
                                                    $order->setCanpaypaymentStatus($transactionDetails['status']);

                                                    $quote->setGrandTotal($quote->getGrandTotal() + $transactionDetails['tip_amount']);
                                                    $quote->setBaseGrandTotal($quote->getBaseGrandTotal() + $transactionDetails['tip_amount']);
                                                    $quote->setTipAmount($transactionDetails['tip_amount']);
                                                    $quote->setCanpaypaymentIntentId($intentId);
                                                }
                                            }
                                            $transaction->save();
                                        }
                                        $quote->save();
                                        $order->save();
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                $this->logger->error('CanPay_Payment ERROR: Order history was not updated. Message: ' . $e->getMessage());
            }
        }
    }
}
