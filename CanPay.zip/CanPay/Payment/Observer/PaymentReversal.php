<?php

namespace CanPay\Payment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Message\ManagerInterface as MessageManagerInterface;
use Psr\Log\LoggerInterface;
use CanPay\Payment\Helper\Data as Helper;
use CanPay\Payment\Helper\Api as HelperApi;
use Magento\Framework\App\Config\ScopeConfigInterface;

class PaymentReversal implements ObserverInterface {

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var HelperApi
     */
    protected $helperApi;

    /**
     *
     * @var MessageManagerInterface
     */
    protected $messageManager;

    /**
     *
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @param LoggerInterface $logger
     * @param Helper $helper
     * @param HelperApi $helperApi
     * @param MessageManagerInterface $messageManager
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        LoggerInterface $logger,
        Helper $helper,
        HelperApi $helperApi,
        MessageManagerInterface $messageManager,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->logger = $logger;
        $this->helper = $helper;
        $this->helperApi = $helperApi;
        $this->messageManager = $messageManager;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * @param EventObserver $observer
     * @return void
     */
    public function execute(EventObserver $observer) {
        if ($this->helper->getEnable()) {
            $order = $observer->getEvent()->getOrder();
            $oldOrder = $this->helper->getCurrentOrder();
            if (!$oldOrder) {
                $payment = $order->getPayment();
                $intentId = $order->getCanpaypaymentIntentId();
                $transactionId = $payment->getLastTransId();
                try {
                    if ($this->helper->isCanPayPayment($order)) {
                        if (stripos($transactionId, 'void') === false) {
                            if ($intentId && $transactionId) {
                                $result = $this->helperApi->paymentReversal($intentId);
                                if ($result) {
                                    if ($result['code'] == 200) {
                                        if (isset($result['message'])) {
                                            $this->messageManager->addSuccessMessage(__('CanPay Payment paymentreversal: ' . $result['message']));
                                        }
                                    } else {
                                        if (isset($result['message'])) {
                                            $this->messageManager->addErrorMessage(__('CanPay_Payment ERROR paymentreversal: ' . $result['message']) . ' A refund will need to be done manually');
                                            $this->logger->error('CanPay_Payment ERROR paymentreversal: ' . $result['message']);
                                        }
                                    }
                                }
                            }
                        } else {
                            $this->messageManager->addSuccessMessage(__('CanPay Payment: Transaction has already been voided'));
                        }
                    }
                } catch (Exception $e) {
                    $this->logger->error('CanPay_Payment ERROR: Payment Reversal. Message: ' . $e->getMessage());
                }
            }
        }
    }
}
