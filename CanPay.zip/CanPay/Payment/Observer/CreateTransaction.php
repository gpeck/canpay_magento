<?php

namespace CanPay\Payment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface as TransactionBuilderInterface;
use Magento\Sales\Model\Order\Payment\Transaction;
use CanPay\Payment\Helper\Data as Helper;
use CanPay\Payment\Helper\Api as HelperApi;

class CreateTransaction implements ObserverInterface {

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var TransactionBuilderInterface
     */
    protected $transactionBuilder;

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var HelperApi
     */
    protected $helperApi;

    /**
     * @param LoggerInterface $logger
     * @param TransactionBuilderInterface $transactionBuilder
     * @param Helper $helper
     * @param HelperApi $helperApi
     */
    public function __construct(
        LoggerInterface $logger,
        TransactionBuilderInterface $transactionBuilder,
        Helper $helper,
        HelperApi $helperApi
    ) {
        $this->logger = $logger;
        $this->transactionBuilder = $transactionBuilder;
        $this->helper = $helper;
        $this->helperApi = $helperApi;
    }

    /**
     * @param EventObserver $observer
     * @return void
     * @throws \Exception
     */
    public function execute(EventObserver $observer) {
        if ($this->helper->getEnable()) {
            try {
                $payment = $observer->getEvent()->getPayment();
                $order = $payment->getOrder();
                if ($this->helper->isCanPayPayment($order)) {
                    if (count($this->helper->getTransactionsByOrderId($order->getId())) == 0) {
                        if ($intentId = $order->getCanpaypaymentIntentId()) {
                            if ($transactionDetails = $this->helperApi->getTransactionDetails($intentId)) {
                                if ($transactionDetails['transaction_number']) {
                                    $payment->setTransactionId($transactionDetails['transaction_number']);
                                    $payment->setIsTransactionPending(false);
                                    $formatedPrice = $order->getBaseCurrency()->formatTxt($order->getGrandTotal());
                                    $message = __('The authorized amount is %1.', $formatedPrice);
                                    $transaction = $this->transactionBuilder->setPayment($payment)
                                        ->setOrder($order)
                                        ->setTransactionId($payment->getTransactionId())
                                        ->setAdditionalInformation(
                                            [\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS => $transactionDetails]
                                        )
                                        ->setFailSafe(true)
                                        ->build(Transaction::TYPE_AUTH);
                                    $payment->addTransactionCommentsToOrder($transaction, $message);
                                    $payment->setIsTransactionClosed(false);
                                    $order->setCanpaypaymentStatus($transactionDetails['status']);
                                    $transaction->save();
                                    $payment->save();
                                    $order->save();
                                }
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                $this->logger->error('CanPay_Payment ERROR: Transaction was not created. Message: ' . $e->getMessage());
            }
        }
    }
}
