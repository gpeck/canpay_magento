<?php

namespace CanPay\Payment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use CanPay\Payment\Helper\Data as Helper;

class SaveDataToOrder implements ObserverInterface {

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     * @param LoggerInterface $logger
     * @param Helper $helper
     */
    public function __construct(
        LoggerInterface $logger,
        Helper $helper
    ) {
        $this->logger = $logger;
        $this->helper = $helper;
    }

    /**
     * @param EventObserver $observer
     * @return void
     */
    public function execute(EventObserver $observer) {
        if ($this->helper->getEnable()) {
            try {
                $order = $observer->getEvent()->getOrder();
                $oldOrder = $this->helper->getCurrentOrder();
                $quote = $this->helper->getQuoteById($order->getQuoteId());
                $tipAmount = $this->helper->getTipAmount($quote);
                $order->setTipAmount($tipAmount);

                if ($intentId = $quote->getCanpaypaymentIntentId()) {
                    $order->setCanpaypaymentIntentId($intentId);
                } else {
                    if ($oldOrder && $order->getId() !== $oldOrder->getId()) {
                        if (!$order->getIsTipApplied()) {
                            $order->setGrandTotal($order->getGrandTotal() + $tipAmount);
                            $order->setBaseGrandTotal($order->getBaseGrandTotal() + $tipAmount);
                            $order->setIsTipApplied(true);
                        }
                        if ($intentId = $oldOrder->getCanpaypaymentIntentId()) {
                            $order->setCanpaypaymentIntentId($intentId);
                        }
                    }
                }
            } catch (Exception $e) {
                $this->logger->error('CanPay_Payment ERROR: intent_id was not saved. Message: ' . $e->getMessage());
            }
        }
    }
}
