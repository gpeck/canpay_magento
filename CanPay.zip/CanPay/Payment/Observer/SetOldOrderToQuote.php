<?php

namespace CanPay\Payment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use CanPay\Payment\Helper\Data as Helper;

class SetOldOrderToQuote implements ObserverInterface {

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     * @param LoggerInterface $logger
     * @param Helper $helper
     */
    public function __construct(
        LoggerInterface $logger,
        Helper $helper
    ) {
        $this->logger = $logger;
        $this->helper = $helper;
    }

    /**
     * @param EventObserver $observer
     * @return void
     */
    public function execute(EventObserver $observer) {
        if ($this->helper->getEnable()) {
            try {
                $quote = $observer->getEvent()->getQuote();
                $oldOrder = $this->helper->getCurrentOrder();
                if ($oldOrder) {
                    $quote->setOldOrderId($oldOrder->getId());
                }
            } catch (Exception $e) {
                $this->logger->error('CanPay_Payment ERROR: Old order id was not set. Message: ' . $e->getMessage());
            }
        }
    }
}
