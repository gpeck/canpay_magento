<?php

namespace CanPay\Payment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Webapi\Controller\Rest\InputParamsResolver;
use Psr\Log\LoggerInterface;
use Magento\Quote\Model\QuoteRepository;
use Magento\Framework\App\State;
use CanPay\Payment\Helper\Data as Helper;

class SaveAdditionalPaymentData implements ObserverInterface {

    /**
     *
     * @var InputParamsResolver
     */
    protected $inputParamsResolver;

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @var QuoteRepository
     */
    protected $quoteRepository;

    /**
     *
     * @var State
     */
    protected $state;

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @param InputParamsResolver $inputParamsResolver
     * @param QuoteRepository $quoteRepository
     * @param LoggerInterface $logger
     * @param State $state
     * @param Helper $helper
     */
    public function __construct(
        InputParamsResolver $inputParamsResolver,
        QuoteRepository $quoteRepository,
        LoggerInterface $logger,
        State $state,
        Helper $helper
    ) {
        $this->inputParamsResolver = $inputParamsResolver;
        $this->quoteRepository = $quoteRepository;
        $this->logger = $logger;
        $this->state = $state;
        $this->helper = $helper;
    }

    /**
     * @param EventObserver $observer
     * @return void
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Webapi\Exception
     */
    public function execute(EventObserver $observer) {
        if ($this->helper->getEnable()) {
            try {
                if ($this->state->getAreaCode() !== \Magento\Framework\App\Area::AREA_ADMINHTML && $this->state->getAreaCode() !== \Magento\Framework\App\Area::AREA_CRONTAB){
                    $inputParams = $this->inputParamsResolver->resolve();
                    foreach ($inputParams as $inputParam) {
                        if ($inputParam instanceof \Magento\Quote\Model\Quote\Payment) {
                            $paymentData = $inputParam->getData('additional_data');
                            $paymentOrder = $observer->getEvent()->getPayment();
                            $order = $paymentOrder->getOrder();
                            $quote = $this->quoteRepository->get($order->getQuoteId());
                            $paymentQuote = $quote->getPayment();
                            if ($this->helper->isCanPayPayment($order)) {
                                if (isset($paymentData['canpaypayment_signature'])){
                                    $paymentQuote->setAdditionalInformation('canpaypayment_signature', $paymentData['canpaypayment_signature']);
                                    $paymentQuote->setAdditionalInformation('canpaypayment_response', $paymentData['canpaypayment_response']);
                                    $paymentOrder->setAdditionalInformation('canpaypayment_signature', $paymentData['canpaypayment_signature']);
                                    $paymentOrder->setAdditionalInformation('canpaypayment_response', $paymentData['canpaypayment_response']);
                                }
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                $this->logger->error('CanPay_Payment ERROR: Additional Information was not added. Message: ' . $e->getMessage());
            }
        }
    }
}
