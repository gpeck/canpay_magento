<?php

namespace CanPay\Payment\Controller\Adminhtml\GetTransactionDetails;

use Magento\Backend\App\Action\Context;
use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\Controller\ResultFactory;
use CanPay\Payment\Helper\Data as Helper;
use CanPay\Payment\Helper\Api as HelperApi;
use Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface as TransactionBuilderInterface;
use Magento\Sales\Model\Order\Payment\Transaction;
use Psr\Log\LoggerInterface;

class Index extends Action
{
    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var HelperApi
     */
    protected $helperApi;

    /**
     *
     * @var TransactionBuilderInterface
     */
    protected $transactionBuilder;

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @param Context $context
     * @param Helper $helper
     * @param HelperApi $helperApi
     * @param TransactionBuilderInterface $transactionBuilder
     * @param LoggerInterface $logger
     */
    public function __construct(
        Context $context,
        Helper $helper,
        HelperApi $helperApi,
        TransactionBuilderInterface $transactionBuilder,
        LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->helper = $helper;
        $this->helperApi = $helperApi;
        $this->transactionBuilder = $transactionBuilder;
        $this->logger = $logger;
    }

    /**
     * @return Redirect|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        try {
            $orderId = $this->getRequest()->getParam('order_id');
            $order = $this->helper->getOrderById($orderId);
            $payment = $order->getPayment();
            $transactions = $this->helper->getTransactionsByOrderId($orderId);

            /** @var Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            if ($intentId = $order->getCanpaypaymentIntentId()) {
                if ($transactionDetails = $this->helperApi->getTransactionDetails($intentId)) {
                    if (count($transactions)) {
                        foreach ($transactions as $transaction) {
                            if ($transactionDetails['transaction_number']) {
                                $transaction->setAdditionalInformation(\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS, $transactionDetails);
                                $payment->save();
                                $transaction->save();
                            }
                        }
                    } else {
                        if ($transactionDetails['transaction_number']) {
                            $payment->setTransactionId($transactionDetails['transaction_number']);
                            $payment->setIsTransactionPending(false);
                            $formatedPrice = $order->getBaseCurrency()->formatTxt($order->getGrandTotal());
                            $message = __('The authorized amount is %1.', $formatedPrice);
                            $transaction = $this->transactionBuilder->setPayment($payment)
                                ->setOrder($order)
                                ->setTransactionId($payment->getTransactionId())
                                ->setAdditionalInformation(
                                    [\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS => $transactionDetails]
                                )
                                ->setFailSafe(true)
                                ->build(Transaction::TYPE_AUTH);
                            $payment->addTransactionCommentsToOrder($transaction, $message);
                            $payment->setIsTransactionClosed(false);
                            $order->setCanpaypaymentStatus($transactionDetails['status']);
                            $payment->save();
                            $transaction->save();
                            $order->save();
                        }
                    }
                    return $resultRedirect->setPath('sales/transactions/view', ['txn_id' => $transaction->getId()]);
                }
            }
            return $resultRedirect->setPath('sales/order/view', ['order_id' => $orderId]);
        } catch (Exception $e) {
            $this->logger->error('CanPay_Payment ERROR: Transaction was not created (updated). Message: ' . $e->getMessage());
            return $resultRedirect->setPath('sales/order/view', ['order_id' => $orderId]);
        }
    }
}
