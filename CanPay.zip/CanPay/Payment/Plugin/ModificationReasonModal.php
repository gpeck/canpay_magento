<?php

namespace CanPay\Payment\Plugin;

use CanPay\Payment\Helper\Data as Helper;
use Magento\Framework\Registry;

class ModificationReasonModal
{

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @var Registry
     */
    protected $coreRegistry;

    /**
     * @param Helper $helper
     * @param Registry $coreRegistry
     */
    public function __construct(
        Helper $helper,
        Registry $coreRegistry
    ) {
        $this->helper = $helper;
        $this->coreRegistry = $coreRegistry;
    }

    /**
     * @param \Magento\Sales\Block\Adminhtml\Order\Create $subject
     * @param $result
     * @return mixed|string
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function afterToHtml(
        \Magento\Sales\Block\Adminhtml\Order\Create $subject,
        $result
    ) {
        if ($this->helper->getEnable() && $subject->getNameInLayout() == 'order_content' && $this->helper->isCanPayPayment($this->helper->getCurrentOrder())) {
            $modificationReasonModalBlockHtml = $subject->getLayout()->createBlock(
                \CanPay\Payment\Block\Adminhtml\Order\ModificationReasonModal::class,
                $subject->getNameInLayout().'_modification_reason_modal'
            )->setTemplate('CanPay_Payment::order/modification_reason_modal.phtml')
                ->toHtml();

            return $result.$modificationReasonModalBlockHtml;
        }
        return $result;
    }

    /**
     * @return \Magento\Sales\Model\Order
     */
    public function getOrder()
    {
        return $this->coreRegistry->registry('sales_order');
    }
}
