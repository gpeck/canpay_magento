<?php

namespace CanPay\Payment\Plugin\Block\Adminhtml\Order;

use Magento\Framework\UrlInterface;
use CanPay\Payment\Helper\Data as Helper;

class View
{
    const STORE_PICKUP_METHOD = 'instore_pickup';

    /**
     *
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     *
     * @var Helper
     */
    protected $helper;

    /**
     *
     * @param UrlInterface $urlBuilder
     * @param Helper $helper
     */
    public function __construct(
        UrlInterface $urlBuilder,
        Helper $helper
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->helper = $helper;
    }

    public function beforeSetLayout(\Magento\Sales\Block\Adminhtml\Order\View $view)
    {
        if ($this->helper->getEnable()) {
            $order = $view->getOrder();
            if ($this->helper->isCanPayPayment($order)) {
                $urlGetTransactionDetails = $this->urlBuilder->getUrl('canpaypayment/gettransactiondetails/index', ['order_id' =>$order->getId()]);
                $view->addButton(
                    'get_transaction_details',
                    [
                        'label' => __('Get Transaction Details'),
                        'class' => 'get-transaction-details',
                        'onclick' => "setLocation('" . $urlGetTransactionDetails. "')",
                    ]
                );
                if ($order->getShippingMethod() == self::STORE_PICKUP_METHOD) {
                    $urlFulfillOrder = $this->urlBuilder->getUrl('canpaypayment/fulfillorder/index', ['order_id' =>$order->getId()]);
                    $view->addButton(
                        'fulfill_order_and_accept_payment',
                        [
                            'label' => __('Fulfill Order and Accept Payment'),
                            'class' => 'fulfill-order-and-accept-payment',
                            'onclick' => "setLocation('" . $urlFulfillOrder. "')",
                        ]
                    );
                }
            }
        }
    }
}
