<?php

namespace CanPay\Payment\Api\Repository;

interface CanPayRepositoryInterface
{

    /**
     *
     * @return string
     */
    public function saveAuthId();

    /**
    *
    * @return string
    */
    public function getCanPayConfig();

    /**
     *
     * @return string|boolean
     */
    public function saveIntentIdToQuote($intentId);

    /**
     *
     * @return float
     */
    public function getCartAmount();

    /**
     *
     * @return string
     */
    public function checkSignature();

    /**
     *
     * @return string
     */
    public function callback();

    /**
     * @return false|string
     */
    public function getModificationReason();

    /**
     * @return false|string
     */
    public function saveModificationReasonId();

    /**
     * @return false|string
     */
    public function getDashboardData();

    /**
     * @param $transactionData
     * @return false|string
     */
    public function getOrderData($transactionData);

    /**
     * @return false|string
     */
    public function loadMoreTransactionsData();

    /**
     * @return false|string
     */
    public function getModificationReasonType();
}
