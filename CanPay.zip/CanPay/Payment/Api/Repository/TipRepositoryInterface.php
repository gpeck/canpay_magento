<?php

namespace CanPay\Payment\Api\Repository;

interface TipRepositoryInterface
{

    /**
     * @return array|bool[]
     */
    public function applyTip();

    /**
     * @return false|string
     */
    public function cancelTip();
}
